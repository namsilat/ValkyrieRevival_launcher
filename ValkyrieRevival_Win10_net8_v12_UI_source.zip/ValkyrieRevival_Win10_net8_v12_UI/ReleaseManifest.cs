namespace ValkyrieRevival;

internal sealed record ReleaseManifest(string Version, string File, string Sha256, int Size);
