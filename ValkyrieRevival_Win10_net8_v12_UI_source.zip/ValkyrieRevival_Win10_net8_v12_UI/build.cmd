@echo off
call "%~dp0PUBLISH_WIN10.cmd"
exit /b %ERRORLEVEL%
