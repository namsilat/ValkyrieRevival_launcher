using System.Text;
using System.Text.RegularExpressions;

namespace ValkyrieRevival;

internal static class DesktopAudio
{
    private static readonly Regex Lines = new(@"[^\r\n]+(?:\r\n|\r|\n|$)|\r\n|\r|\n", RegexOptions.Compiled);
    private static readonly Regex Output = new(@"^AudioOutputDevice\s*=", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    internal static string ClearOculusOutput(string text)
    {
        var result = new StringBuilder(text.Length);
        bool oculus = false;
        foreach (Match match in Lines.Matches(text))
        {
            string value = match.Value;
            string trimmed = value.Trim();
            if (trimmed.StartsWith('[') && trimmed.EndsWith(']'))
                oculus = trimmed.Equals("[Oculus.Settings]", StringComparison.OrdinalIgnoreCase);

            if (oculus && Output.IsMatch(trimmed))
                continue;
            result.Append(value);
        }
        return result.ToString();
    }

    internal static void Prepare(string mode)
    {
        if (mode is not ("desktop" or "meta-desktop")) return;

        string path = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "VkGame", "Saved", "Config", "WindowsNoEditor", "Engine.ini");
        if (!File.Exists(path)) return;

        string original = File.ReadAllText(path);
        string cleaned = ClearOculusOutput(original);
        if (cleaned == original) return;

        string pending = path + "." + Guid.NewGuid().ToString("N") + ".pending";
        string backup = path + ".revival-audio-" + Guid.NewGuid().ToString("N") + ".bak";
        try
        {
            File.WriteAllText(pending, cleaned, new UTF8Encoding(false));
            File.Replace(pending, path, backup, ignoreMetadataErrors: true);
        }
        finally
        {
            if (File.Exists(pending)) File.Delete(pending);
        }
    }
}
