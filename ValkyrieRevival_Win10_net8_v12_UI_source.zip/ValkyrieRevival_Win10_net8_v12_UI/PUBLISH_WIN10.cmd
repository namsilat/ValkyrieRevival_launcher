@echo off
setlocal
cd /d "%~dp0"
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0publish-win10-x64.ps1"
set ERR=%ERRORLEVEL%
echo.
if not "%ERR%"=="0" (
  echo BUILD FAILED. Error code: %ERR%
) else (
  echo BUILD OK. See publish\win10-x64\ValkyrieRevival.exe
)
pause
exit /b %ERR%
