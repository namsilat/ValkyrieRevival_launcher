using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.IO;
using System.Net.Http;

namespace ValkyrieRevival;

internal sealed class Bridge : IDisposable
{
    private readonly TcpListener listener;
    private readonly HttpClient http;
    private readonly string session;
    private readonly int pilot;
    private readonly bool legacy;
    private readonly string upstream;
    private readonly SemaphoreSlim slots = new(64);
    private readonly CancellationTokenSource stop = new();
    private static readonly object traceLock = new();

    internal int Port => ((IPEndPoint)listener.LocalEndpoint).Port;

    internal Bridge(int pilot, string session, int port, HttpMessageHandler? handler = null, bool legacy = false)
    {
        this.pilot = pilot;
        this.session = session;
        this.legacy = legacy;
        upstream = legacy ? LegacyEndpoint.Base : Program.Api + "/game";

        handler ??= new HttpClientHandler
        {
            AllowAutoRedirect = false,
            UseCookies = false,
            MaxConnectionsPerServer = legacy ? 8 : int.MaxValue
        };
        http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(30) };
        listener = new TcpListener(IPAddress.Loopback, port) { ExclusiveAddressUse = true };
        listener.Start(64);
    }

    private static void Trace(bool legacy, string method, string path, int status, string? failure = null)
    {
        if (!legacy) return;
        try
        {
            string file = Path.Combine(Program.State, "legacy-bridge-requests.jsonl");
            string line = JsonSerializer.Serialize(new
            {
                time = DateTimeOffset.UtcNow,
                method,
                path = path.Split('?', StringSplitOptions.None)[0],
                status,
                failure
            }) + Environment.NewLine;
            lock (traceLock) File.AppendAllText(file, line);
        }
        catch { }
    }

    private static async Task<string> Line(NetworkStream stream, CancellationToken ct)
    {
        byte[] one = new byte[1];
        using var buffer = new MemoryStream();
        while (buffer.Length < 8192)
        {
            int read = await stream.ReadAsync(one.AsMemory(0, 1), ct).ConfigureAwait(false);
            if (read == 0) throw new IOException("Incomplete request.");
            if (one[0] == (byte)'\n')
                return Encoding.ASCII.GetString(buffer.ToArray()).TrimEnd('\r');
            buffer.WriteByte(one[0]);
        }
        throw new IOException("Request line too long.");
    }

    private static string Rewrite(string value) => Regex.Replace(
        value,
        @"http://127\.0\.0\.1:10[0-9]{3}/",
        "http://127.0.0.1:10080/",
        RegexOptions.CultureInvariant);

    private string RewriteResponse(string value) => legacy ? LegacyEndpoint.Rewrite(value, Port) : Rewrite(value);

    private string UpstreamPath(string path)
    {
        if (!legacy) return path;
        string prefix = "/" + LegacyGame.CacheTenant(pilot) + "/";
        return path.StartsWith(prefix, StringComparison.Ordinal)
            ? "/live/" + path[prefix.Length..]
            : path;
    }

    private static async Task Reply(NetworkStream stream, int code, byte[] data, string? location, CancellationToken ct)
    {
        var header = new StringBuilder()
            .Append("HTTP/1.1 ").Append(code).Append(" Response\r\n")
            .Append("Content-Type: application/json\r\n")
            .Append("Content-Length: ").Append(data.Length).Append("\r\n")
            .Append("Connection: close\r\n");

        if (!string.IsNullOrEmpty(location) && !location.Contains('\r') && !location.Contains('\n'))
            header.Append("Location: ").Append(location).Append("\r\n");
        header.Append("\r\n");

        byte[] head = Encoding.ASCII.GetBytes(header.ToString());
        await stream.WriteAsync(head, ct).ConfigureAwait(false);
        await stream.WriteAsync(data, ct).ConfigureAwait(false);
    }

    private async Task Handle(TcpClient client)
    {
        using (client)
        using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(stop.Token))
        {
            timeout.CancelAfter(TimeSpan.FromSeconds(45));
            CancellationToken ct = timeout.Token;
            string methodText = "?";
            string path = "/";
            try
            {
                NetworkStream stream = client.GetStream();
                string requestLine = await Line(stream, ct).ConfigureAwait(false);
                string[] parts = requestLine.Split(' ', StringSplitOptions.None);
                if (parts.Length != 3 || (parts[2] != "HTTP/1.0" && parts[2] != "HTTP/1.1"))
                    throw new IOException("Invalid request.");

                methodText = parts[0];
                path = parts[1];
                if (methodText is not ("GET" or "POST" or "PUT" or "PATCH" or "DELETE"))
                    throw new IOException("Invalid request.");
                if (!path.StartsWith('/') || path.StartsWith("//", StringComparison.Ordinal) || path.Contains('\\') || path.Contains('#'))
                    throw new IOException("Invalid path.");

                var headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                int headerChars = 0;
                while (true)
                {
                    string line = await Line(stream, ct).ConfigureAwait(false);
                    if (line.Length == 0) break;
                    headerChars += line.Length;
                    if (headerChars > 32768) throw new IOException("Invalid headers.");
                    int colon = line.IndexOf(':');
                    if (colon < 1) throw new IOException("Invalid headers.");
                    string name = line[..colon].Trim();
                    string value = line[(colon + 1)..].Trim();
                    if (!headers.TryAdd(name, value)) throw new IOException("Invalid headers.");
                }

                if (headers.TryGetValue("Transfer-Encoding", out _))
                    throw new IOException("Chunked input unsupported.");

                int contentLength = 0;
                if (headers.TryGetValue("Content-Length", out string? lengthText) &&
                    (!int.TryParse(lengthText, out contentLength) || contentLength < 0 || contentLength > 1_048_576))
                    throw new IOException("Invalid request size.");

                byte[] body = new byte[contentLength];
                if (contentLength > 0)
                    await stream.ReadExactlyAsync(body, ct).ConfigureAwait(false);

                if (methodText == "GET" && path == "/health")
                {
                    byte[] health = JsonSerializer.SerializeToUtf8Bytes(new
                    {
                        service = "remote-https-bridge",
                        pilot,
                        game = legacy ? "legacy" : "warzone"
                    });
                    await Reply(stream, 200, health, null, ct).ConfigureAwait(false);
                    Trace(legacy, methodText, path, 200);
                    return;
                }

                using var outgoing = new HttpRequestMessage(new HttpMethod(methodText), upstream + UpstreamPath(path));
                outgoing.Headers.Authorization = new AuthenticationHeaderValue("Bearer", session);
                if (body.Length > 0 || methodText is "POST" or "PUT" or "PATCH")
                    outgoing.Content = new ByteArrayContent(body);

                if (headers.TryGetValue("Content-Type", out string? contentType) && outgoing.Content is not null)
                    outgoing.Content.Headers.TryAddWithoutValidation("Content-Type", contentType);

                string[] allowed = ["accept", "vk-version", "vk-requestid", "vk-clientguid", "vk-runnumber"];
                foreach ((string name, string value) in headers)
                {
                    if (allowed.Contains(name, StringComparer.OrdinalIgnoreCase))
                        outgoing.Headers.TryAddWithoutValidation(name, value);
                }

                using HttpResponseMessage response = await http.SendAsync(outgoing, HttpCompletionOption.ResponseHeadersRead, ct).ConfigureAwait(false);
                byte[] data;
                await using (Stream responseStream = await response.Content.ReadAsStreamAsync(ct).ConfigureAwait(false))
                    data = await Updater.ReadBounded(responseStream, 8_388_608, ct).ConfigureAwait(false);

                string rewritten = RewriteResponse(Encoding.UTF8.GetString(data));
                byte[] responseData = Encoding.UTF8.GetBytes(rewritten);
                string? location = response.Headers.Location?.ToString();
                if (location is not null) location = RewriteResponse(location);
                await Reply(stream, (int)response.StatusCode, responseData, location, ct).ConfigureAwait(false);
                Trace(legacy, methodText, path, (int)response.StatusCode);
            }
            catch (Exception ex) when (ex is IOException or HttpRequestException or OperationCanceledException or FormatException or OverflowException or ArgumentException)
            {
                string failure = ex is HttpRequestException hre
                    ? $"{hre.HttpRequestError}; inner={hre.InnerException?.GetType().Name}; code={hre.InnerException?.HResult}; message={hre.InnerException?.Message}"
                    : ex.GetType().Name;
                Trace(legacy, methodText, path, 503, failure);
                try
                {
                    byte[] error = Encoding.UTF8.GetBytes("{\"error\":\"bridge unavailable\"}");
                    await Reply(client.GetStream(), 503, error, null, CancellationToken.None).ConfigureAwait(false);
                }
                catch { }
            }
        }
    }

    internal async Task Run()
    {
        while (!stop.IsCancellationRequested)
        {
            try
            {
                TcpClient client = await listener.AcceptTcpClientAsync(stop.Token).ConfigureAwait(false);
                if (!await slots.WaitAsync(0, stop.Token).ConfigureAwait(false))
                {
                    client.Dispose();
                    continue;
                }
                _ = Task.Run(async () =>
                {
                    try { await Handle(client).ConfigureAwait(false); }
                    finally { slots.Release(); }
                });
            }
            catch (OperationCanceledException) when (stop.IsCancellationRequested) { break; }
            catch (SocketException) when (stop.IsCancellationRequested) { break; }
        }
    }

    public void Dispose()
    {
        stop.Cancel();
        listener.Stop();
        http.Dispose();
    }

    internal static async Task RunHelper(bool smoke, bool launchGame)
    {
        string? assignmentLine = await Console.In.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(15)).ConfigureAwait(false);
        if (assignmentLine is null) throw new IOException("Missing bridge assignment.");

        using JsonDocument assignment = JsonDocument.Parse(assignmentLine);
        JsonElement root = assignment.RootElement;
        int pilot = root.GetProperty("pilot").GetInt32();
        string? session = root.GetProperty("session").GetString();
        if (pilot < 1 || string.IsNullOrEmpty(session) || session.Length > 4096 || session.Contains('\r') || session.Contains('\n'))
            throw new IOException("Invalid bridge assignment.");

        bool legacy = root.TryGetProperty("game", out JsonElement game) && game.GetString() == "legacy";
        using var bridge = new Bridge(pilot, session, smoke ? 0 : 10080, handler: null, legacy: legacy);
        _ = bridge.Run();

        await Console.Out.WriteLineAsync(smoke ? "READY:" + bridge.Port : "READY").ConfigureAwait(false);
        await Console.Out.FlushAsync().ConfigureAwait(false);

        string? secondLine = await Console.In.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(60)).ConfigureAwait(false);

        if (launchGame)
        {
            using JsonDocument launch = JsonDocument.Parse(secondLine ?? "{}");
            string executable = Path.GetFullPath(launch.RootElement.GetProperty("executable").GetString()!);
            string mode = launch.RootElement.GetProperty("mode").GetString()!;

            if (legacy)
            {
                LegacyGame.VerifyPrepared(executable);
                if (Game.Running()) throw new IOException("Another game is running.");
                using Process legacyProcess = LegacyGame.Start(executable, pilot);
                await Console.Out.WriteLineAsync("PID:" + legacyProcess.Id).ConfigureAwait(false);
                await Console.Out.FlushAsync().ConfigureAwait(false);
                await legacyProcess.WaitForExitAsync().ConfigureAwait(false);
                return;
            }

            if (!Regex.IsMatch(Path.GetFileName(executable), @"\AValkyrie-Remote-[a-f0-9]{12}\.exe\z"))
                throw new IOException("Invalid game executable.");
            if (Game.Running()) throw new IOException("Another game is running.");

            using MetaLaunchLease? lease = mode.StartsWith("meta-", StringComparison.Ordinal)
                ? new MetaLaunchLease(executable)
                : null;
            using Process gameProcess = Game.StartNative(lease?.Executable ?? executable, mode);
            await Console.Out.WriteLineAsync("PID:" + gameProcess.Id).ConfigureAwait(false);
            await Console.Out.FlushAsync().ConfigureAwait(false);
            await gameProcess.WaitForExitAsync().ConfigureAwait(false);
            return;
        }

        if (int.TryParse(secondLine, out int pid) && pid > 0)
            await Task.Run(() => Program.WaitProcess(pid, -1)).ConfigureAwait(false);
    }

}
