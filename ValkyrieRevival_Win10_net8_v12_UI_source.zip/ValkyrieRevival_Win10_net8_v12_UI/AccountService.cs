using System.Text;
using System.Text.Json;

namespace ValkyrieRevival;

internal static class AccountService
{
    internal sealed record RegistrationResult(string Username, int PilotId, string Callsign, string RecoveryCode);
    internal sealed record RecoveryResult(string Username, string? Callsign, string? RecoveryCode);

    internal static async Task<RegistrationResult> Register(string username, string callsign, string password)
    {
        using JsonDocument document = await Post("/api/register", new
        {
            username,
            callsign,
            recovery_code = "",
            password
        }).ConfigureAwait(false);

        JsonElement root = document.RootElement;
        string returnedUsername = ReadString(root, "username") ?? username;
        string recoveryCode = ReadString(root, "recovery_code")
            ?? throw new IOException("Account service did not return a recovery code.");

        int pilotId = 0;
        string returnedCallsign = callsign;
        if (root.TryGetProperty("pilot", out JsonElement pilot) && pilot.ValueKind == JsonValueKind.Object)
        {
            if (pilot.TryGetProperty("pilot_id", out JsonElement pilotIdElement) && pilotIdElement.TryGetInt32(out int parsedPilotId))
                pilotId = parsedPilotId;

            returnedCallsign = ReadString(pilot, "callsign") ?? callsign;
        }

        return new RegistrationResult(returnedUsername, pilotId, returnedCallsign, recoveryCode);
    }

    internal static async Task<RecoveryResult> Recover(string username, string recoveryCode, string newPassword)
    {
        using JsonDocument document = await Post("/api/recover", new
        {
            username,
            callsign = "",
            recovery_code = recoveryCode,
            password = newPassword
        }).ConfigureAwait(false);

        JsonElement root = document.RootElement;
        string returnedUsername = ReadString(root, "username") ?? username;
        string? newRecoveryCode = ReadString(root, "recovery_code");
        string? callsign = null;

        if (root.TryGetProperty("pilot", out JsonElement pilot) && pilot.ValueKind == JsonValueKind.Object)
            callsign = ReadString(pilot, "callsign");

        return new RecoveryResult(returnedUsername, callsign, newRecoveryCode);
    }

    private static async Task<JsonDocument> Post(string path, object payload)
    {
        using var handler = new HttpClientHandler
        {
            AllowAutoRedirect = false,
            AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate | DecompressionMethods.Brotli
        };
        using var http = new HttpClient(handler)
        {
            Timeout = TimeSpan.FromSeconds(45)
        };

        using var request = new HttpRequestMessage(HttpMethod.Post, Program.Account.TrimEnd('/') + path)
        {
            Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json")
        };
        request.Headers.TryAddWithoutValidation("Accept", "*/*");
        request.Headers.TryAddWithoutValidation("X-Valkyrie-Request", "1");

        using HttpResponseMessage response = await http.SendAsync(request).ConfigureAwait(false);
        string body = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

        JsonDocument document;
        try
        {
            document = JsonDocument.Parse(string.IsNullOrWhiteSpace(body) ? "{}" : body);
        }
        catch (JsonException)
        {
            if (!response.IsSuccessStatusCode)
                throw new IOException($"Account service returned HTTP {(int)response.StatusCode}.");
            throw new IOException("Account service returned an unreadable response.");
        }

        if (!response.IsSuccessStatusCode)
        {
            using (document)
            {
                throw new IOException(ReadError(document.RootElement) ?? $"Account service returned HTTP {(int)response.StatusCode}.");
            }
        }

        return document;
    }

    private static string? ReadError(JsonElement root)
    {
        foreach (string key in new[] { "error", "message", "detail" })
        {
            string? value = ReadString(root, key);
            if (!string.IsNullOrWhiteSpace(value))
                return value;
        }
        return null;
    }

    private static string? ReadString(JsonElement root, string name)
    {
        if (!root.TryGetProperty(name, out JsonElement value))
            return null;

        return value.ValueKind == JsonValueKind.String ? value.GetString() : null;
    }
}
