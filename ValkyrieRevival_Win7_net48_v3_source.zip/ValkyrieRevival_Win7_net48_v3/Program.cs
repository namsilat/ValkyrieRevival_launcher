using System.Diagnostics;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using System.Windows;
using System.IO;

namespace ValkyrieRevival;

internal static class Program
{
    internal const string Version = "0.2.8";

    // Portable legacy build: launcher state lives next to the executable.
    internal static readonly string LauncherDirectory = Path.GetDirectoryName(Compatibility.ExecutablePath())!;
    internal static readonly string State = LauncherDirectory;
    internal static readonly string SettingsFile = Path.Combine(LauncherDirectory, "launcher-settings.json");
    internal static readonly string CredentialsFile = Path.Combine(LauncherDirectory, "launcher-credentials.json");

    internal static readonly JsonElement Release =
        JsonDocument.Parse(Resource("release.json")).RootElement.Clone();

    internal static string Account => Release.GetProperty("account_url").GetString()!;
    internal static string Api => Release.GetProperty("game_api_url").GetString()!;

    internal static byte[] Resource(string name)
    {
        using Stream? source = Assembly.GetExecutingAssembly().GetManifestResourceStream(name);
        if (source is null)
            throw new InvalidDataException($"Missing launcher asset: {name}");

        using var output = new MemoryStream();
        source.CopyTo(output);
        return output.ToArray();
    }

    internal static string Hash(byte[] data) =>
        Compatibility.Sha256(data);

    internal static string FileHash(string path) => Compatibility.Sha256File(path);

    internal static ProcessStartInfo Self(params string[] args)
    {
        string executable = Compatibility.ExecutablePath();
        var start = new ProcessStartInfo(executable)
        {
            UseShellExecute = false,
            CreateNoWindow = true
        };
        foreach (string arg in args)
            Compatibility.AddArgument(start, arg);
        return start;
    }

    internal static void WaitProcess(int pid, int timeout)
    {
        Process process;
        try { process = Process.GetProcessById(pid); }
        catch (ArgumentException) { return; }

        using (process)
        {
            if (!process.WaitForExit(timeout))
                throw new IOException("The previous process is still running.");
        }
    }

    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            ServicePointManager.SecurityProtocol |= (SecurityProtocolType)3072; // TLS 1.2 on Windows 7
            Directory.CreateDirectory(State);
            Compatibility.LogStartup("START " + Compatibility.EnvironmentDescription());

            if (args.Length > 0)
            {
                switch (args[0])
                {
                    case "--bridge":
                        Bridge.RunHelper(smoke: false, launchGame: false).GetAwaiter().GetResult();
                        return 0;
                    case "--game-host":
                        Bridge.RunHelper(smoke: false, launchGame: true).GetAwaiter().GetResult();
                        return 0;
                    case "--bridge-smoke":
                        Bridge.RunHelper(smoke: true, launchGame: false).GetAwaiter().GetResult();
                        return 0;
                    case "--apply-update" when args.Length == 2:
                        Updater.Apply(args[1]);
                        return 0;
                    case "--self-test" when args.Length == 2:
                        _ = JsonDocument.Parse(Resource("patch.json")).RootElement.GetProperty("target_sha256");
                        File.WriteAllText(args[1], JsonSerializer.Serialize(new
                        {
                            version = Version,
                            account = Account,
                            assets = "ok",
                            runtime = "dotnet",
                            state = State
                        }));
                        return 0;
                    case "--verify":
                        Verification.Run(args.Skip(1).ToArray()).GetAwaiter().GetResult();
                        return 0;
                    case "--connection-test" when args.Length == 2:
                        Verification.Connection(args[1]).GetAwaiter().GetResult();
                        return 0;
                    default:
                        throw new ArgumentException("Unknown launcher option.");
                }
            }

            using var mutex = new Mutex(initiallyOwned: true, "Local\\ValkyrieRevival.Launcher", out bool first);
            if (!first)
            {
                MessageBox.Show("The launcher is already open.", "Valkyrie Revival",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return 0;
            }

            var app = new Application();
            return app.Run(new MainWindow(services: true));
        }
        catch (Exception ex)
        {
            Compatibility.LogStartup("FATAL " + ex);
            MessageBox.Show(ex.GetType().Name + ": " + ex.Message, "Valkyrie Revival",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return 1;
        }
    }
}
