# ValkyrieRevival-Legacy

Windows 7 SP1+ compatibility branch of the reconstructed Valkyrie Revival 0.2.8 launcher.

The source is based on the working Win10 v11 branch and keeps the same game/API behavior and current UI,
while replacing APIs unavailable on .NET Framework 4.8.

See `README_WIN7.md` for build and target-machine instructions.
