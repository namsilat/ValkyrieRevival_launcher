# Windows 7+ port notes

Source base: working Win10 v11 branch.
Target: `net48`, x64, WPF.

Replaced for .NET Framework 4.8 compatibility:

- SHA-256 static helpers and hex conversion APIs.
- Span/Memory-based binary patch operations.
- `ProcessStartInfo.ArgumentList` and modern environment dictionary APIs.
- `Task.WaitAsync`, `Process.WaitForExitAsync`, process-tree kill.
- `Stream.ReadExactlyAsync`, Memory-based read/write overloads.
- `TcpListener.AcceptTcpClientAsync(CancellationToken)`.
- overwrite form of `File.Move`.
- modern WPF `OpenFolderDialog` with `FolderBrowserDialog`.
- `double.IsFinite`, Range/Index syntax, `Dictionary.TryAdd`.
- Brotli enum use in `HttpClientHandler`.
- `HttpRequestException.HttpRequestError` diagnostics.

Windows 7 compatibility additions:

- Explicit TLS 1.2 activation through `ServicePointManager`.
- Windows 7/8/8.1/10 compatibility GUIDs in the application manifest.
- `Segoe UI` instead of Bahnschrift because Bahnschrift is not standard on Windows 7.
- .NET Framework 4.8 reference assemblies provided through NuGet for reproducible builds.

The official launcher self-update remains disabled because official releases target a newer .NET runtime.
