$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-Location $PSScriptRoot
if (Test-Path '.\BUILD_COMPAT_VERSION.txt') { Write-Host ('Source: ' + (Get-Content '.\BUILD_COMPAT_VERSION.txt' -Raw).Trim()) }

$LocalSdk = Join-Path $PSScriptRoot '.dotnet-sdk'
$DotNet = Join-Path $LocalSdk 'dotnet.exe'

function Have-Net8Sdk([string]$exe) {
    if (-not (Test-Path $exe)) { return $false }
    $sdks = & $exe --list-sdks 2>$null
    return [bool]($sdks | Where-Object { $_ -match '^8\.' })
}

if (-not (Have-Net8Sdk $DotNet)) {
    Write-Host '[1/6] Installing a private .NET 8 SDK used only to compile the net48 project ...'
    New-Item -ItemType Directory -Force -Path $LocalSdk | Out-Null
    $installer = Join-Path $env:TEMP 'dotnet-install-vr-win7.ps1'
    Invoke-WebRequest 'https://dot.net/v1/dotnet-install.ps1' -OutFile $installer -UseBasicParsing
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -Channel 8.0 -Architecture x64 -InstallDir $LocalSdk -NoPath
    if (-not (Have-Net8Sdk $DotNet)) { throw 'The private .NET 8 SDK installation did not complete.' }
} else {
    Write-Host '[1/6] Private .NET 8 build SDK is already present.'
}

Write-Host '[2/6] Restoring .NET Framework 4.8 reference assemblies and NuGet dependencies ...'
& $DotNet restore '.\ValkyrieRevival.csproj'
if ($LASTEXITCODE -ne 0) { throw "dotnet restore failed: $LASTEXITCODE" }

$Publish = Join-Path $PSScriptRoot 'publish\win7-x64'
if (Test-Path $Publish) { Remove-Item $Publish -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Publish | Out-Null

Write-Host '[3/6] Building Windows 7+ / .NET Framework 4.8 x64 ...'
& $DotNet build '.\ValkyrieRevival.csproj' -c Release --no-restore -o $Publish -p:PlatformTarget=x64 -p:Prefer32Bit=false
if ($LASTEXITCODE -ne 0) { throw "dotnet build failed: $LASTEXITCODE" }

$Exe = Join-Path $Publish 'ValkyrieRevival-Legacy.exe'
if (-not (Test-Path $Exe)) { throw 'Build completed but ValkyrieRevival-Legacy.exe is missing.' }

Write-Host '[4/6] Writing target-machine notes ...'
@'
VALKYRIE REVIVAL LEGACY - WINDOWS 7+
=====================================
Target: Windows 7 SP1 / Windows 8.1 / Windows 10 / Windows 11 x64
Runtime: Microsoft .NET Framework 4.8

Keep ALL files from this folder together. This is not a .NET 8 self-contained build.
On Windows 7 SP1 install .NET Framework 4.8 before starting the launcher.
TLS 1.2 is explicitly enabled by the launcher for playevevalkyrie.com.

Steam / SteamVR / Meta software may impose their own OS requirements independently
of the launcher itself.
'@ | Set-Content -Encoding UTF8 (Join-Path $Publish 'README-WINDOWS7.txt')

Write-Host '[5/6] Running launcher self-test on this build PC ...'
$Probe = Join-Path $Publish 'self-test.json'
if (Test-Path $Probe) { Remove-Item $Probe -Force }
$p = Start-Process -FilePath $Exe -ArgumentList @('--self-test', $Probe) -WorkingDirectory $Publish -PassThru -Wait
if ($p.ExitCode -ne 0 -or -not (Test-Path $Probe)) {
    throw "Built launcher failed its self-test. Exit code: $($p.ExitCode)"
}
Write-Host (Get-Content $Probe -Raw)
Remove-Item $Probe -Force

Write-Host '[6/6] Creating portable package ...'
$Zip = Join-Path $PSScriptRoot 'publish\ValkyrieRevival-Legacy-Win7plus.zip'
if (Test-Path $Zip) { Remove-Item $Zip -Force }
Compress-Archive -Path (Join-Path $Publish '*') -DestinationPath $Zip -CompressionLevel Optimal

Write-Host ''
Write-Host 'SUCCESS'
Write-Host "EXE: $Exe"
Write-Host "ZIP: $Zip"
