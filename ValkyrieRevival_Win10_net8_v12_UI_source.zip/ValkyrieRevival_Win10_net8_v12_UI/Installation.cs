using System.Text.Json;

namespace ValkyrieRevival;

internal static class Installation
{
    private const string LegacyHash = "b0e1eef5aa308b8bdd58855918cbf6f49382aafc0e761ce2c7e15f0efeb3aca3";

    internal static string Validate(string input, string game)
    {
        if (game is not ("warzone" or "legacy"))
            throw new ArgumentException("Unknown game");

        string label = game == "legacy" ? "Legacy" : "Warzone";
        string full = Path.GetFullPath(input);
        var candidates = new List<string>();

        if (File.Exists(full))
        {
            candidates.Add(full);
        }
        else
        {
            string[] roots =
            [
                full,
                Path.Combine(full, "WindowsNoEditor", "VkGame", "Binaries", "Win64"),
                Path.Combine(full, "Image", "WindowsNoEditor", "VkGame", "Binaries", "Win64"),
                Path.Combine(full, "VkGame", "Binaries", "Win64")
            ];
            foreach (string root in roots)
            {
                foreach (string name in new[] { "EVE Valkyrie - Warzone.exe", "EVE-Valkyrie.exe" })
                {
                    string path = Path.Combine(root, name);
                    if (File.Exists(path)) candidates.Add(Path.GetFullPath(path));
                }
            }
        }

        using JsonDocument document = JsonDocument.Parse(Program.Resource("patch.json"));
        string? warzoneSource = document.RootElement.GetProperty("source_sha256").GetString();
        bool recognizedWrongGame = false;
        bool foundExisting = candidates.Count > 0;

        foreach (string candidate in candidates.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            string hash;
            try { hash = Program.FileHash(candidate); }
            catch (IOException) { continue; }

            string? kind = hash switch
            {
                LegacyHash => "legacy",
                Game.MetaHash => "warzone",
                _ when hash == warzoneSource => "warzone",
                _ => null
            };

            if (kind == game) return candidate;
            if (kind is not null) recognizedWrongGame = true;
        }

        if (recognizedWrongGame)
        {
            string opposite = game == "legacy" ? "Warzone" : "Legacy";
            throw new IOException($"This is a {opposite} installation. Change the game selection or choose your {label} folder.");
        }

        if (foundExisting)
            throw new IOException($"Unsupported {label} executable. Select an installation with a supported original game build.");

        throw new IOException($"No supported game executable was found. Choose your {label} installation folder or its Win64 folder.");
    }
}
