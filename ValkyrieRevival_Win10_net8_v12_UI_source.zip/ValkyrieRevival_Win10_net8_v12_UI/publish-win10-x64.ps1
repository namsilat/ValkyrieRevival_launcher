$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-Location $PSScriptRoot

$LocalSdk = Join-Path $PSScriptRoot '.dotnet-sdk'
$DotNet = Join-Path $LocalSdk 'dotnet.exe'

function Have-Net8Sdk([string]$exe) {
    if (-not (Test-Path $exe)) { return $false }
    $sdks = & $exe --list-sdks 2>$null
    return [bool]($sdks | Where-Object { $_ -match '^8\.' })
}

if (-not (Have-Net8Sdk $DotNet)) {
    Write-Host '[1/5] Installing a private .NET 8 SDK into .dotnet-sdk ...'
    New-Item -ItemType Directory -Force -Path $LocalSdk | Out-Null
    $installer = Join-Path $env:TEMP 'dotnet-install-vr.ps1'
    Invoke-WebRequest 'https://dot.net/v1/dotnet-install.ps1' -OutFile $installer -UseBasicParsing
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -Channel 8.0 -Architecture x64 -InstallDir $LocalSdk -NoPath
    if (-not (Have-Net8Sdk $DotNet)) { throw 'The .NET 8 SDK installation did not complete.' }
} else {
    Write-Host '[1/5] Private .NET 8 SDK is already present.'
}

Write-Host '[2/5] SDK information:'
& $DotNet --version

$Publish = Join-Path $PSScriptRoot 'publish\win10-x64'
if (Test-Path $Publish) { Remove-Item $Publish -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Publish | Out-Null

Write-Host '[3/5] Restoring packages ...'
& $DotNet restore '.\ValkyrieRevival.csproj' -r win-x64
if ($LASTEXITCODE -ne 0) { throw "dotnet restore failed: $LASTEXITCODE" }

Write-Host '[4/5] Publishing self-contained single-file Win10 x64 build ...'
& $DotNet publish '.\ValkyrieRevival.csproj' -c Release -r win-x64 --self-contained true --no-restore -o $Publish `
    -p:PublishSingleFile=true `
    -p:PublishTrimmed=false `
    -p:PublishReadyToRun=false `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -p:EnableCompressionInSingleFile=false
if ($LASTEXITCODE -ne 0) { throw "dotnet publish failed: $LASTEXITCODE" }

$Exe = Join-Path $Publish 'ValkyrieRevival.exe'
if (-not (Test-Path $Exe)) { throw 'Publish completed but ValkyrieRevival.exe is missing.' }

Write-Host '[5/5] Running launcher self-test ...'
$Probe = Join-Path $Publish 'self-test.json'
if (Test-Path $Probe) { Remove-Item $Probe -Force }
$p = Start-Process -FilePath $Exe -ArgumentList @('--self-test', $Probe) -WorkingDirectory $Publish -PassThru -Wait
if ($p.ExitCode -ne 0 -or -not (Test-Path $Probe)) {
    throw "The built launcher failed its self-test. Exit code: $($p.ExitCode)"
}
Write-Host (Get-Content $Probe -Raw)
Remove-Item $Probe -Force

Write-Host ''
Write-Host 'SUCCESS'
Write-Host "EXE: $Exe"
Write-Host 'The EXE is self-contained: .NET does not need to be installed on the target PC.'
