namespace ValkyrieRevival;

internal static class LegacyEndpoint
{
    internal const string Local = "http://127.0.0.1:18379/legacy/game";
    internal const string Live = "https://api.playevevalkyrie.com/legacy/game";

    internal static string Resolve(string? environment) => environment switch
    {
        "local" => Local,
        null or "" or "private-live" => Live,
        _ => throw new IOException("Unknown Legacy preview environment.")
    };

    internal static string Base => Resolve(Environment.GetEnvironmentVariable("VALKYRIE_LEGACY_ENVIRONMENT"));

    internal static string Rewrite(string input, int port) => input
        .Replace(Local + "/", $"http://127.0.0.1:{port}/", StringComparison.Ordinal)
        .Replace(Live + "/", $"http://127.0.0.1:{port}/", StringComparison.Ordinal);
}
