@echo off
setlocal
cd /d "%~dp0publish\win7-x64"
if not exist ValkyrieRevival-Legacy.exe (
  echo ValkyrieRevival-Legacy.exe not found. Run BUILD_WIN7.cmd first.
  pause
  exit /b 1
)
ValkyrieRevival-Legacy.exe
echo.
echo Exit code: %ERRORLEVEL%
echo Startup log: %CD%\startup.log
pause
