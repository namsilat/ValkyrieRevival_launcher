@echo off
setlocal
cd /d "%~dp0publish\win10-x64"
if not exist ValkyrieRevival.exe (
  echo ValkyrieRevival.exe not found. Run PUBLISH_WIN10.cmd first.
  pause
  exit /b 1
)
set COREHOST_TRACE=1
set COREHOST_TRACE_VERBOSITY=4
set COREHOST_TRACEFILE=%CD%\host-trace.txt
ValkyrieRevival.exe
echo.
echo Exit code: %ERRORLEVEL%
echo Host trace: %CD%\host-trace.txt
echo Managed startup log: %%LOCALAPPDATA%%\ValkyrieRevival\startup.log
pause
