# Valkyrie Revival — Windows 10 compatibility build

This branch is reconstructed from ValkyrieRevival 0.2.8 and retargeted from .NET 10 to .NET 8.

## Target

- Windows 10 x64, with the project minimum declared as build 14393 (1607).
- .NET 8 self-contained.
- Single EXE publish, preserving the launcher's self-replacement assumptions.
- No system-wide .NET installation is required on the target PC.

## Important change

Official launcher self-update is deliberately disabled in this compatibility build. An official update could replace this EXE with the original .NET 10 build and reintroduce the startup problem. Game/API/bridge logic is unchanged.

## Build

Run:

    PUBLISH_WIN10.cmd

The script downloads a private .NET 8 SDK into `.dotnet-sdk` if necessary, restores dependencies, publishes `win-x64`, then runs the built-in `--self-test`.

Output:

    publish\win10-x64\ValkyrieRevival.exe

## Diagnostics

After a successful build run:

    RUN_DIAGNOSTIC.cmd

Logs:

    publish\win10-x64\host-trace.txt
    %LOCALAPPDATA%\ValkyrieRevival\startup.log

## Compatibility edits

- `net10.0-windows` -> `net8.0-windows10.0.17763.0`
- minimum OS declaration -> Windows 10 build 14393
- self-contained `win-x64` single-file publish
- disabled trimming and ReadyToRun for conservative compatibility
- replaced .NET 9+ `Convert.ToHexStringLower` with .NET 8-compatible code
- executable-path lookup has a fallback suitable for single-file deployment
- automatic official launcher update disabled
- startup environment/fatal exceptions logged to `%LOCALAPPDATA%\ValkyrieRevival\startup.log`

## Build fix v2
This package contains explicit global namespaces (`GlobalUsings.cs`) so compilation does not depend on SDK implicit-usings generation. It fixes CS0246 errors for `FileStream`, `Stream`, `HttpClient`, and `HttpMessageHandler` seen in the first package.


## Compatibility source revision

This package is **v3**. `BUILD_COMPAT_VERSION.txt` must say `Win10 compatibility source v3`.

## v4 friend-list compatibility

The original launcher requires an exact whole-file SHA-256 for the intermediate image immediately before the friend-list patch. In the reconstructed Win10 build this can reject an otherwise supported base game after the main game patch and authentication layout have already passed.

v4 keeps the safety-critical local verification: every friend-list patch offset must contain the exact original `before` bytes from the embedded recipe. If the whole-file intermediate hash differs but those bytes are correct, v4 applies the patch and logs both hashes to `%LOCALAPPDATA%\\ValkyrieRevival\\startup.log` instead of rejecting the build solely on the whole-file hash.

## v6 UI / portable settings

- UI is rendered at 80% scale compared with v5.
- Scrollbars use a dark launcher-native style.
- Game ComboBox and its popup are fully dark themed.
- Password field has a show/hide eye button.
- Portable state is stored next to `ValkyrieRevival.exe`.
- `launcher-settings.json` stores launcher/game preferences.
- `launcher-credentials.json` stores the remembered username and a Windows-DPAPI-encrypted password blob (not plaintext).
- On first run, an existing remembered credential from the older Windows Credential Manager storage is migrated automatically when possible.

## v7 window placement
The launcher now remembers its normal window position, size, and maximized state in `launcher-settings.json` next to the EXE. Stale/off-screen coordinates are ignored so the window remains reachable after monitor-layout changes.

## v9 account UI

The launcher now contains three account tabs: **PILOT LOGIN**, **REGISTRATION**, and **RECOVER**.

Registration uses the official account endpoint at `https://playevevalkyrie.com/api/register`. After a successful registration the returned recovery code is written to a separate `recovery-code-<username>.txt` file next to the launcher executable. This file is deliberately human-readable so it can be used if the password is lost; keep it private.

Password recovery uses the official endpoint at `https://playevevalkyrie.com/api/recover`. If the service returns a replacement recovery code, the local recovery file is updated automatically.

## v12 UI adjustment
- Restored the left artwork behavior from v9: `Stretch="UniformToFill"`.
- The artwork fills the entire left panel again, centered by WPF and cropped automatically when aspect ratios differ.
- Registration/Recover tab behavior from v10+ is preserved.
