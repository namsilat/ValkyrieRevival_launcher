@echo off
setlocal
cd /d "%~dp0"
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-win7.ps1"
set ERR=%ERRORLEVEL%
echo.
if not "%ERR%"=="0" (
  echo BUILD FAILED. Error code: %ERR%
) else (
  echo BUILD OK.
  echo Output: publish\win7-x64\
  echo Package: publish\ValkyrieRevival-Legacy-Win7plus.zip
)
pause
exit /b %ERR%
