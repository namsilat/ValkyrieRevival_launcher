using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;

namespace ValkyrieRevival;

internal static class Compatibility
{
    internal const string BuildFlavor = "Windows 7+ legacy / .NET Framework 4.8";
    internal static readonly bool OfficialLauncherUpdatesEnabled = false;

    internal static bool IsFinite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);

    internal static string HexLower(byte[] data) => HexLower(data, 0, data.Length);

    internal static string HexLower(byte[] data, int offset, int count)
    {
        const string hex = "0123456789abcdef";
        char[] chars = new char[count * 2];
        for (int i = 0; i < count; i++)
        {
            byte b = data[offset + i];
            chars[i * 2] = hex[b >> 4];
            chars[i * 2 + 1] = hex[b & 0x0F];
        }
        return new string(chars);
    }

    internal static byte[] HexToBytes(string value)
    {
        if (value == null) throw new ArgumentNullException(nameof(value));
        if ((value.Length & 1) != 0) throw new FormatException("Hex string length must be even.");
        byte[] result = new byte[value.Length / 2];
        for (int i = 0; i < result.Length; i++)
        {
            int hi = HexNibble(value[i * 2]);
            int lo = HexNibble(value[i * 2 + 1]);
            if (hi < 0 || lo < 0) throw new FormatException("Invalid hexadecimal string.");
            result[i] = (byte)((hi << 4) | lo);
        }
        return result;
    }

    private static int HexNibble(char c)
    {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    }

    internal static string Sha256(byte[] data)
    {
        using (SHA256 sha = SHA256.Create())
            return HexLower(sha.ComputeHash(data));
    }

    internal static string Sha256File(string path)
    {
        using (SHA256 sha = SHA256.Create())
        using (FileStream input = File.OpenRead(path))
            return HexLower(sha.ComputeHash(input));
    }

    internal static bool BytesEqual(byte[] source, int offset, byte[] expected)
    {
        if (source == null || expected == null || offset < 0 || offset + expected.Length > source.Length)
            return false;
        for (int i = 0; i < expected.Length; i++)
            if (source[offset + i] != expected[i]) return false;
        return true;
    }

    internal static void CopyBytes(byte[] source, byte[] destination, int destinationOffset)
    {
        Buffer.BlockCopy(source, 0, destination, destinationOffset, source.Length);
    }

    internal static bool IsPathFullyQualified(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) return false;
        path = path.Trim();

        // UNC path: \\server\share\...
        if (path.Length >= 2 && path[0] == '\\' && path[1] == '\\')
            return true;

        // Drive-rooted path: C:\... or C:/...
        return path.Length >= 3 &&
               char.IsLetter(path[0]) &&
               path[1] == ':' &&
               (path[2] == '\\' || path[2] == '/');
    }

    internal static string ExecutablePath()
    {
        try
        {
            using (Process process = Process.GetCurrentProcess())
            {
                ProcessModule? module = process.MainModule;
                if (module != null && !string.IsNullOrWhiteSpace(module.FileName))
                    return module.FileName!;
            }
        }
        catch { }

        string[] args = Environment.GetCommandLineArgs();
        if (args.Length > 0 && !string.IsNullOrWhiteSpace(args[0]))
        {
            string commandPath = Path.GetFullPath(args[0]);
            if (File.Exists(commandPath))
                return commandPath;
        }
        throw new IOException("Cannot locate launcher executable.");
    }

    internal static void AddArgument(ProcessStartInfo start, string argument)
    {
        string quoted = QuoteArgument(argument);
        start.Arguments = string.IsNullOrEmpty(start.Arguments) ? quoted : start.Arguments + " " + quoted;
    }

    private static string QuoteArgument(string argument)
    {
        if (argument.Length > 0 && argument.IndexOfAny(new[] { ' ', '\t', '\n', '\v', '"' }) < 0)
            return argument;

        var sb = new StringBuilder();
        sb.Append('"');
        int slashes = 0;
        foreach (char c in argument)
        {
            if (c == '\\') { slashes++; continue; }
            if (c == '"')
            {
                sb.Append('\\', slashes * 2 + 1);
                sb.Append('"');
                slashes = 0;
                continue;
            }
            if (slashes > 0) { sb.Append('\\', slashes); slashes = 0; }
            sb.Append(c);
        }
        if (slashes > 0) sb.Append('\\', slashes * 2);
        sb.Append('"');
        return sb.ToString();
    }

    internal static void SetEnvironment(ProcessStartInfo start, string name, string value) =>
        start.EnvironmentVariables[name] = value;

    internal static void RemoveEnvironment(ProcessStartInfo start, string name) =>
        start.EnvironmentVariables.Remove(name);

    internal static void MoveReplace(string source, string destination)
    {
        if (File.Exists(destination)) File.Delete(destination);
        File.Move(source, destination);
    }

    internal static void Kill(Process process)
    {
        try { if (!process.HasExited) process.Kill(); } catch { }
    }

    internal static async Task<T> WithTimeout<T>(Task<T> task, TimeSpan timeout)
    {
        Task delay = Task.Delay(timeout);
        Task completed = await Task.WhenAny(task, delay).ConfigureAwait(false);
        if (completed != task) throw new TimeoutException("Operation timed out.");
        return await task.ConfigureAwait(false);
    }

    internal static async Task WithTimeout(Task task, TimeSpan timeout)
    {
        Task delay = Task.Delay(timeout);
        Task completed = await Task.WhenAny(task, delay).ConfigureAwait(false);
        if (completed != task) throw new TimeoutException("Operation timed out.");
        await task.ConfigureAwait(false);
    }

    internal static Task WaitForExitAsync(Process process)
    {
        if (process.HasExited) return Task.FromResult(0);
        var tcs = new TaskCompletionSource<int>();
        process.EnableRaisingEvents = true;
        EventHandler? handler = null;
        handler = (s, e) =>
        {
            process.Exited -= handler;
            tcs.TrySetResult(0);
        };
        process.Exited += handler;
        if (process.HasExited)
        {
            process.Exited -= handler;
            tcs.TrySetResult(0);
        }
        return tcs.Task;
    }

    internal static async Task ReadExactlyAsync(Stream stream, byte[] buffer, CancellationToken cancellationToken)
    {
        int offset = 0;
        while (offset < buffer.Length)
        {
            int read = await stream.ReadAsync(buffer, offset, buffer.Length - offset, cancellationToken).ConfigureAwait(false);
            if (read == 0) throw new EndOfStreamException("Incomplete request body.");
            offset += read;
        }
    }

    internal static void LogStartup(string message)
    {
        try
        {
            Directory.CreateDirectory(Program.State);
            File.AppendAllText(Path.Combine(Program.State, "startup.log"),
                "[" + DateTimeOffset.Now.ToString("O") + "] " + message + Environment.NewLine);
        }
        catch { }
    }

    internal static string EnvironmentDescription() =>
        BuildFlavor + "; OS=" + Environment.OSVersion + "; CLR=" + Environment.Version +
        "; 64bit=" + Environment.Is64BitProcess;
}
