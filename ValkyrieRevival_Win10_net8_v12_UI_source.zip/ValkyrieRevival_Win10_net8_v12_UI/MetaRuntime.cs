using System.Security;
using Microsoft.Win32;

namespace ValkyrieRevival;

internal static class MetaRuntime
{
    internal const string PlatformDll = "LibOVRPlatform64_1.dll";

    private static string? Read(RegistryView view, string key, string value)
    {
        try
        {
            using RegistryKey baseKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, view);
            using RegistryKey? subKey = baseKey.OpenSubKey(key);
            return subKey?.GetValue(value) as string;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or SecurityException)
        {
            return null;
        }
    }

    private static string? ServiceDirectory(string? command)
    {
        if (string.IsNullOrWhiteSpace(command)) return null;
        string value = Environment.ExpandEnvironmentVariables(command.Trim());
        string executable;
        if (value.StartsWith('"'))
        {
            int end = value.IndexOf('"', 1);
            if (end < 2) return null;
            executable = value[1..end];
        }
        else
        {
            int end = value.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
            if (end < 0) return null;
            executable = value[..(end + 4)];
        }
        if (!Path.IsPathFullyQualified(executable)) return null;
        return Path.GetDirectoryName(executable);
    }

    private static string? Select(IEnumerable<string?> candidates, Func<string, bool> predicate)
    {
        foreach (string? raw in candidates)
        {
            if (string.IsNullOrWhiteSpace(raw)) continue;
            try
            {
                string candidate = Environment.ExpandEnvironmentVariables(raw.Trim().Trim('"'));
                if (!Path.IsPathFullyQualified(candidate)) continue;
                if (predicate(Path.Combine(candidate, PlatformDll)))
                    return candidate;
            }
            catch (Exception ex) when (ex is ArgumentException or NotSupportedException or IOException or UnauthorizedAccessException)
            {
            }
        }
        return null;
    }

    internal static string Find()
    {
        string? service = ServiceDirectory(Read(
            RegistryView.Registry64,
            @"SYSTEM\CurrentControlSet\Services\OVRService",
            "ImagePath"));

        string? base64 = Read(RegistryView.Registry64, @"SOFTWARE\Oculus VR, LLC\Oculus", "Base");
        string? base32 = Read(RegistryView.Registry32, @"SOFTWARE\Oculus VR, LLC\Oculus", "Base");
        string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);

        string? selected = Select(new[]
        {
            service,
            string.IsNullOrWhiteSpace(base64) ? null : Path.Combine(base64, "Support", "oculus-runtime"),
            string.IsNullOrWhiteSpace(base32) ? null : Path.Combine(base32, "Support", "oculus-runtime"),
            Path.Combine(programFiles, "Meta Horizon", "Support", "oculus-runtime"),
            Path.Combine(programFiles, "Oculus", "Support", "oculus-runtime")
        }, File.Exists);

        return selected ?? throw new IOException(
            "Meta PC runtime not found. Repair the Meta PC app installation so its runtime is registered. Required file: LibOVRPlatform64_1.dll");
    }
}
