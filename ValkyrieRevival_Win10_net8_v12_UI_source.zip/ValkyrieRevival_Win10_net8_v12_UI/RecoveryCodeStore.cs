using System.Text;

namespace ValkyrieRevival;

internal static class RecoveryCodeStore
{
    internal static string Save(string username, string? callsign, string recoveryCode)
    {
        string safeUser = SafeFilePart(username);
        string path = Path.Combine(Program.LauncherDirectory, $"recovery-code-{safeUser}.txt");
        string pending = path + "." + Guid.NewGuid().ToString("N") + ".pending";

        var text = new StringBuilder();
        text.AppendLine("VALKYRIE REVIVAL ACCOUNT RECOVERY");
        text.AppendLine("=================================");
        text.AppendLine();
        text.AppendLine($"Username: {username}");
        if (!string.IsNullOrWhiteSpace(callsign))
            text.AppendLine($"Public callsign: {callsign}");
        text.AppendLine($"Recovery code: {recoveryCode}");
        text.AppendLine($"Saved UTC: {DateTime.UtcNow:O}");
        text.AppendLine();
        text.AppendLine("IMPORTANT: Keep this file private. Anyone with this recovery code may be able to reset the account password.");

        try
        {
            File.WriteAllText(pending, text.ToString(), new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
            File.Move(pending, path, true);
            return path;
        }
        finally
        {
            if (File.Exists(pending))
                File.Delete(pending);
        }
    }

    private static string SafeFilePart(string value)
    {
        HashSet<char> invalid = Path.GetInvalidFileNameChars().ToHashSet();
        string safe = new string(value.Select(c => invalid.Contains(c) ? '_' : c).ToArray()).Trim();
        return string.IsNullOrWhiteSpace(safe) ? "account" : safe;
    }
}
