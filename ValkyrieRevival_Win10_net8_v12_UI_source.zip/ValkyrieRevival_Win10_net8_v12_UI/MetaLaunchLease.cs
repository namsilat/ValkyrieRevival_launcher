using System.IO;
namespace ValkyrieRevival;

internal sealed class MetaLaunchLease : IDisposable
{
    private const string TargetHash = Game.MetaHash;
    private const string HandoffTargetHash = "357e51eed499e73c7ad7b3a090733829a516436f57b414b10e255661fe79e0fd";
    private const string PreviousTargetHash = "7fbe7cfea828f13bb838d2c729a206014e0a287e09ebf94ec2a0f75e32e6f57c";
    private const string PreviousTargetHash2 = "67e6dc6efd7abe1b570f150e8b9df0700743b5eb647c2c3f77ba1e593f061dc0";

    private readonly string original;
    private readonly FileStream guard;

    internal string Executable => original;

    private static string Backup(string original) => Path.Combine(
        Path.GetDirectoryName(original)!,
        "Valkyrie-Meta-Original-" + TargetHash[..12] + ".bak");

    private static FileStream Lock(string original) =>
        new(original + ".revival-lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);

    private static void Replace(string target, byte[] data)
    {
        string pending = target + "." + Guid.NewGuid().ToString("N") + ".pending";
        try
        {
            using (var output = new FileStream(pending, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                output.Write(data);
                output.Flush(flushToDisk: true);
            }
            File.Move(pending, target, overwrite: true);
        }
        finally
        {
            if (File.Exists(pending)) File.Delete(pending);
        }
    }

    private static void Restore(string original)
    {
        string hash = Program.FileHash(original);
        if (hash == TargetHash) return;

        if (hash is not (HandoffTargetHash or PreviousTargetHash or PreviousTargetHash2) ||
            Program.FileHash(Backup(original)) != TargetHash)
            throw new IOException("Meta recovery found an unexpected file. Your backup has been preserved.");

        Replace(original, File.ReadAllBytes(Backup(original)));
        if (Program.FileHash(original) != TargetHash)
            throw new IOException("Meta original restoration verification failed.");
    }

    internal static void Recover(string original)
    {
        if (!File.Exists(Backup(original))) return;
        if (Game.Running())
            throw new IOException("Close the running game before preparing the Meta installation.");

        using FileStream guard = Lock(original);
        Restore(original);
    }

    internal MetaLaunchLease(string handoff)
    {
        original = Path.Combine(Path.GetDirectoryName(handoff)!, "EVE Valkyrie - Warzone.exe");
        if (Program.FileHash(handoff) != HandoffTargetHash)
            throw new IOException("Unexpected Oculus game executable.");

        guard = Lock(original);
        try
        {
            if (Program.FileHash(original) != TargetHash)
                throw new IOException("Meta original must be restored before launch.");

            string backup = Backup(original);
            if (!File.Exists(backup))
            {
                using var output = new FileStream(backup, FileMode.CreateNew, FileAccess.Write, FileShare.None);
                output.Write(File.ReadAllBytes(original));
                output.Flush(flushToDisk: true);
            }

            if (Program.FileHash(backup) != TargetHash)
                throw new IOException("Meta original backup checksum mismatch.");

            Replace(original, File.ReadAllBytes(handoff));
        }
        catch
        {
            guard.Dispose();
            throw;
        }
    }

    public void Dispose()
    {
        try
        {
            int retry = 0;
            while (true)
            {
                try
                {
                    Restore(original);
                    break;
                }
                catch (Exception ex) when (retry < 119 && ex is IOException or UnauthorizedAccessException)
                {
                    Thread.Sleep(500);
                    retry++;
                }
            }
        }
        finally
        {
            guard.Dispose();
        }
    }
}
