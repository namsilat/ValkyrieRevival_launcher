# Decompilation notes

The supplied EXE is a .NET single-file application targeting `.NETCoreApp,Version=v10.0/win-x64`.
The managed program was extracted as `ValkyrieRevival.dll`. No meaningful symbol/name obfuscation
was observed: class names, method names, strings and compiler-generated async state-machine names
are intact.

The recovered source lifts standard async state machines back into `async` / `await` methods.
Where exact original source syntax cannot be inferred from IL (local variable names, expression
style, comments, XAML source formatting), the reconstruction chooses a simple equivalent form.

The full IL dump is authoritative for checking a questionable reconstruction detail.
