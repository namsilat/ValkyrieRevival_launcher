using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Win32;

namespace ValkyrieRevival;

internal static class Game
{
    internal const string MetaHash = "68220d1c8b70cf94ed6c37b245cf3f756ec1a46d646d39f914e4aaa8e1de37b6";

    internal static string Find(string input)
    {
        string file = "EVE Valkyrie - Warzone.exe";
        string[] candidates =
        [
            input,
            Path.Combine(input, file),
            Path.Combine(input, "WindowsNoEditor", "VkGame", "Binaries", "Win64", file),
            Path.Combine(input, "Image", "WindowsNoEditor", "VkGame", "Binaries", "Win64", file),
            Path.Combine(input, "VkGame", "Binaries", "Win64", file)
        ];

        foreach (string candidate in candidates)
            if (Path.GetFileName(candidate).Equals(file, StringComparison.OrdinalIgnoreCase) && File.Exists(candidate))
                return Path.GetFullPath(candidate);

        throw new IOException("Select the EVE Valkyrie installation folder or its Win64 folder.");
    }

    internal static byte[] Patch(byte[] input)
    {
        string recipeName = Program.Hash(input) == MetaHash ? "meta-patch.json" : "patch.json";
        using JsonDocument document = JsonDocument.Parse(Program.Resource(recipeName));
        JsonElement recipe = document.RootElement;

        if (Program.Hash(input) != recipe.GetProperty("source_sha256").GetString())
            throw new IOException("This game version is unsupported. The original executable has not been changed.");

        byte[] append = Convert.FromHexString(recipe.GetProperty("append").GetString() ?? "");
        byte[] output = new byte[input.Length + append.Length];
        input.CopyTo(output, 0);
        append.CopyTo(output, input.Length);

        foreach (JsonElement change in recipe.GetProperty("changes").EnumerateArray())
        {
            int offset = change.GetProperty("offset").GetInt32();
            byte[] before = Convert.FromHexString(change.GetProperty("before").GetString()!);
            byte[] after = Convert.FromHexString(change.GetProperty("after").GetString()!);
            if (before.Length != after.Length || offset < 0 || offset + before.Length > output.Length ||
                !output.AsSpan(offset, before.Length).SequenceEqual(before))
                throw new IOException("Client patch verification failed.");
            after.CopyTo(output.AsSpan(offset, after.Length));
        }

        if (Program.Hash(output) != recipe.GetProperty("target_sha256").GetString())
            throw new IOException("Patched client checksum failed.");
        return output;
    }

    internal static byte[] FriendsPatch(byte[] input)
    {
        using JsonDocument document = JsonDocument.Parse(Program.Resource("friends-patch.json"));
        JsonElement recipe = document.RootElement;

        string actualSourceHash = Program.Hash(input);
        string expectedSourceHash = recipe.GetProperty("source_sha256").GetString() ?? "";
        bool exactKnownBuild = actualSourceHash.Equals(expectedSourceHash, StringComparison.OrdinalIgnoreCase);

        if (!exactKnownBuild)
        {
            // Win10 compatibility build: the main game patch and authentication layout have already
            // been verified before reaching this method.  Do not reject solely because the whole-file
            // hash of that intermediate image differs.  We still require every friend-patch site's
            // original bytes to match exactly before touching the executable.
            Compatibility.LogStartup(
                $"FriendsPatch compatibility mode: actual={actualSourceHash}, expected={expectedSourceHash}");
        }

        byte[] append = Convert.FromHexString(recipe.GetProperty("append").GetString() ?? "");
        byte[] output = new byte[input.Length + append.Length];
        input.CopyTo(output, 0);
        append.CopyTo(output, input.Length);

        foreach (JsonElement change in recipe.GetProperty("changes").EnumerateArray())
        {
            int offset = change.GetProperty("offset").GetInt32();
            byte[] before = Convert.FromHexString(change.GetProperty("before").GetString()!);
            byte[] after = Convert.FromHexString(change.GetProperty("after").GetString()!);

            if (before.Length != after.Length || offset < 0 || offset + before.Length > output.Length)
                throw new IOException("Friend-list patch recipe is invalid for this executable.");

            if (!output.AsSpan(offset, before.Length).SequenceEqual(before))
            {
                string actualBytes = Compatibility.HexLower(output.AsSpan(offset, before.Length));
                string expectedBytes = Compatibility.HexLower(before);
                throw new IOException(
                    $"Friend-list patch site is unsupported at 0x{offset:X}: " +
                    $"found {actualBytes}, expected {expectedBytes}.");
            }

            after.CopyTo(output.AsSpan(offset, after.Length));

            if (!output.AsSpan(offset, after.Length).SequenceEqual(after))
                throw new IOException("Friend-list patch write verification failed.");
        }

        string actualTargetHash = Program.Hash(output);
        string expectedTargetHash = recipe.GetProperty("target_sha256").GetString() ?? "";

        if (exactKnownBuild && !actualTargetHash.Equals(expectedTargetHash, StringComparison.OrdinalIgnoreCase))
            throw new IOException("Friend-list client checksum failed.");

        if (!exactKnownBuild)
        {
            Compatibility.LogStartup(
                $"FriendsPatch compatibility result: actual={actualTargetHash}, " +
                $"officialTarget={expectedTargetHash}");
        }

        return output;
    }

    internal static byte[] RemotePatch(byte[] input)
    {
        ReadOnlySpan<byte> expected = Convert.FromHexString("33db488d4dc78bd348895dd7");
        if (input.Length < 34364261 + expected.Length || !input.AsSpan(34364261, expected.Length).SequenceEqual(expected))
            throw new IOException("Unexpected authentication request layout.");

        byte[] output = (byte[])input.Clone();
        byte[] request = Encoding.Unicode.GetBytes("grant_type=community_local");
        ulong length = (ulong)request.Length / 2;

        using var code = new MemoryStream();
        using (var writer = new BinaryWriter(code, Encoding.UTF8, leaveOpen: true))
        {
            writer.Write(Convert.FromHexString("488d05"));
            writer.Write(32);
            writer.Write(Convert.FromHexString("488945c748b8"));
            writer.Write((length << 32) | length);
            writer.Write(Convert.FromHexString("488945cf488d4dc7"));
            writer.Write((byte)0xE8);
            writer.Write(34340560 - (34366821 + checked((int)code.Length) + 4));
            writer.Write((byte)0xE9);
            writer.Write(34367277 - (34366821 + checked((int)code.Length) + 4));

            if (code.Length != 39)
                throw new IOException("Authentication patch size mismatch.");
            writer.Write(request);
        }

        code.ToArray().CopyTo(output, 34364261);
        return FriendsPatch(output);
    }

    internal static string Prepare(string input)
    {
        string path = Find(input);
        byte[] source = File.ReadAllBytes(path);
        byte[] patched = Program.Hash(source) == MetaHash ? Patch(source) : RemotePatch(Patch(source));
        string hash = Program.Hash(patched);
        string target = Path.Combine(Path.GetDirectoryName(path)!, "Valkyrie-Remote-" + hash[..12] + ".exe");

        if (File.Exists(target))
        {
            if (Program.FileHash(target) != hash)
                throw new IOException("An unexpected remote client file exists. It was left untouched.");
            return target;
        }

        string pending = target + "." + Guid.NewGuid().ToString("N") + ".pending";
        try
        {
            using (var file = new FileStream(pending, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                file.Write(patched);
            File.Move(pending, target);
        }
        finally
        {
            if (File.Exists(pending)) File.Delete(pending);
        }
        return target;
    }

    internal static bool Running()
    {
        foreach (Process process in Process.GetProcesses())
        {
            try
            {
                string name = process.ProcessName;
                if (name.Equals("EVE Valkyrie - Warzone", StringComparison.OrdinalIgnoreCase) ||
                    (name.StartsWith("Valkyrie-", StringComparison.OrdinalIgnoreCase) &&
                     !name.StartsWith("Valkyrie-Battle-Host", StringComparison.OrdinalIgnoreCase) &&
                     !name.Equals("Valkyrie-Legacy-Host", StringComparison.OrdinalIgnoreCase) &&
                     !name.StartsWith("Valkyrie-Legacy-AccountHost", StringComparison.OrdinalIgnoreCase)))
                    return true;
            }
            catch { }
            finally { process.Dispose(); }
        }
        return false;
    }

    internal static string[] Arguments(string mode) => mode switch
    {
        "meta-desktop" => ["-oculus", "-tenant=live", "-localhost", "-2d", "-nohmd", "-fullscreen"],
        "meta-vr" => ["-oculus", "-tenant=live", "-localhost", "-vr"],
        "desktop" => ["-steam", "-tenant=live", "-localhost", "-2d", "-nohmd", "-fullscreen"],
        "steamvr" => ["-steam", "-tenant=live", "-localhost", "-vr", "-hmd=SteamVR"],
        _ => throw new ArgumentException("Choose Desktop or SteamVR.")
    };

    internal static async Task<(int pilot, string session)> Authenticate(string user, string password, bool registerWarzone)
    {
        var cookies = new CookieContainer();
        using var handler = new HttpClientHandler { CookieContainer = cookies, AllowAutoRedirect = false };
        using var http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(45) };
        using var request = new HttpRequestMessage(HttpMethod.Post, Program.Account + "/api/login")
        {
            Content = new StringContent(JsonSerializer.Serialize(new { username = user, password }), Encoding.UTF8, "application/json")
        };
        request.Headers.Add("X-Valkyrie-Request", "1");

        using HttpResponseMessage response = await http.SendAsync(request).ConfigureAwait(false);
        using JsonDocument document = JsonDocument.Parse(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
        JsonElement root = document.RootElement;
        if (!response.IsSuccessStatusCode)
            throw new IOException(root.TryGetProperty("error", out JsonElement error) ? error.GetString() : "Sign in failed.");

        int pilot = root.GetProperty("pilot").GetProperty("pilot_id").GetInt32();
        string session = cookies.GetCookies(new Uri(Program.Account))["valkyrie_session"]?.Value
            ?? throw new IOException("Account service did not return a session.");
        if (!registerWarzone) return (pilot, session);

        using var registration = new HttpRequestMessage(HttpMethod.Post, Program.Api + "/game/live/clients")
        {
            Content = new StringContent("{}", Encoding.UTF8, "application/json")
        };
        registration.Headers.Authorization = new AuthenticationHeaderValue("Bearer", session);
        using HttpResponseMessage assigned = await http.SendAsync(registration).ConfigureAwait(false);
        assigned.EnsureSuccessStatusCode();
        using JsonDocument assignedDocument = JsonDocument.Parse(await assigned.Content.ReadAsStringAsync().ConfigureAwait(false));
        if (assignedDocument.RootElement.GetProperty("pilot_id").GetInt32() != pilot)
            throw new IOException("Remote pilot assignment mismatch.");
        return (pilot, session);
    }

    internal static async Task<Process> Launch(string user, string password, string selected, string selectedMode)
    {
        string original = Find(selected);
        MetaLaunchLease.Recover(original);

        string mode;
        if (Program.FileHash(original) == MetaHash)
        {
            mode = selectedMode switch
            {
                "desktop" => "meta-desktop",
                "steamvr" => "meta-vr",
                _ => throw new IOException("Choose Desktop or VR.")
            };
        }
        else
        {
            VerifySteam();
            mode = selectedMode;
        }

        if (Running())
            throw new IOException("Close the running game before launching another pilot.");

        _ = Arguments(mode);
        (int pilot, string session) = await Authenticate(user, password, registerWarzone: true).ConfigureAwait(false);
        string client = Prepare(selected);

        var start = Program.Self("--game-host");
        start.RedirectStandardInput = true;
        start.RedirectStandardOutput = true;
        start.RedirectStandardError = true;
        Process bridge = Process.Start(start) ?? throw new IOException("Cannot start local game connection.");
        try
        {
            await bridge.StandardInput.WriteLineAsync(JsonSerializer.Serialize(new { pilot, session })).ConfigureAwait(false);
            await bridge.StandardInput.FlushAsync().ConfigureAwait(false);

            string? ready = await bridge.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(15)).ConfigureAwait(false);
            if (ready != "READY")
                throw new IOException("Cannot open the local game connection. Close any other game or old launcher bridge and retry.");

            if (Running())
                throw new IOException("Another game was started. Close it before trying again.");

            await bridge.StandardInput.WriteLineAsync(JsonSerializer.Serialize(new { executable = client, mode })).ConfigureAwait(false);
            await bridge.StandardInput.FlushAsync().ConfigureAwait(false);
            string? line = await bridge.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(15)).ConfigureAwait(false);
            if (line is null || !line.StartsWith("PID:", StringComparison.Ordinal) || !int.TryParse(line[4..], out int pid))
                throw new IOException("Game startup failed. Close other game instances and try again.");

            bridge.StandardInput.Close();
            return Process.GetProcessById(pid);
        }
        catch
        {
            try { if (!bridge.HasExited) bridge.Kill(entireProcessTree: true); } catch { }
            throw;
        }
        finally
        {
            bridge.Dispose();
        }
    }

    internal static Process StartNative(string executable, string mode)
    {
        DesktopAudio.Prepare(mode);
        var start = new ProcessStartInfo(executable)
        {
            UseShellExecute = false,
            WorkingDirectory = Path.GetDirectoryName(executable)!
        };
        foreach (string arg in Arguments(mode)) start.ArgumentList.Add(arg);
        start.Environment["OPENSSL_ia32cap"] = ":~0x20000000";

        if (!mode.StartsWith("meta-", StringComparison.Ordinal))
        {
            start.Environment["SteamAppId"] = "688480";
            start.Environment["SteamGameId"] = "688480";
        }
        else
        {
            start.Environment.Remove("SteamAppId");
            start.Environment.Remove("SteamGameId");
        }
        start.Environment.Remove("VALKYRIE_REMOTE_SESSION");

        if (mode.StartsWith("meta-", StringComparison.Ordinal))
        {
            string runtime = MetaRuntime.Find();
            start.Environment["PATH"] = runtime + Path.PathSeparator + start.Environment["PATH"];
        }
        return Process.Start(start) ?? throw new IOException("Cannot launch game.");
    }

    internal static void VerifySteam()
    {
        int pid = 0;
        int activeUser = 0;
        using (RegistryKey baseKey = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64))
        using (RegistryKey? key = baseKey.OpenSubKey(@"Software\Valve\Steam\ActiveProcess"))
        {
            if (key?.GetValue("pid") is int p) pid = p;
            if (key?.GetValue("ActiveUser") is int a) activeUser = a;
        }

        try
        {
            using Process steam = Process.GetProcessById(pid);
            if (steam.HasExited || !steam.ProcessName.Equals("steam", StringComparison.OrdinalIgnoreCase))
                throw new IOException();
        }
        catch
        {
            throw new IOException("Steam's connection is unavailable. Exit Steam completely, reopen it from your desktop, and sign in before pressing Play again.");
        }

        if (activeUser == 0)
            throw new IOException("Sign in to your Steam profile and wait for Steam to finish loading, then press Play again.");
    }
}
