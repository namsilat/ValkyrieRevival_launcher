using System.Text.Json;

namespace ValkyrieRevival;

internal sealed class GamePreferences
{
    internal string WarzoneFolder { get; set; } = "";
    internal string LegacyFolder { get; set; } = "";
    internal string LastPlayed { get; set; } = "warzone";
    internal string WarzoneMode { get; set; } = "desktop";

    internal double? WindowLeft { get; set; }
    internal double? WindowTop { get; set; }
    internal double? WindowWidth { get; set; }
    internal double? WindowHeight { get; set; }
    internal bool WindowMaximized { get; set; }

    internal string Folder(string game) => game == "legacy" ? LegacyFolder : WarzoneFolder;

    internal void SetFolder(string game, string folder)
    {
        if (game == "legacy") LegacyFolder = folder;
        else WarzoneFolder = folder;
    }

    internal void Launched(string game)
    {
        if (game != "warzone" && game != "legacy")
            throw new ArgumentException("Unknown game");
        LastPlayed = game;
    }

    internal static GamePreferences Parse(string json)
    {
        using JsonDocument document = JsonDocument.Parse(json);
        JsonElement root = document.RootElement;

        string Read(string name, string fallback) =>
            root.TryGetProperty(name, out JsonElement value) && value.ValueKind == JsonValueKind.String
                ? value.GetString() ?? fallback
                : fallback;

        double? ReadDouble(string name) =>
            root.TryGetProperty(name, out JsonElement value) &&
            value.ValueKind == JsonValueKind.Number &&
            value.TryGetDouble(out double result) &&
            Compatibility.IsFinite(result)
                ? result
                : null;

        bool ReadBool(string name, bool fallback = false) =>
            root.TryGetProperty(name, out JsonElement value) &&
            (value.ValueKind == JsonValueKind.True || value.ValueKind == JsonValueKind.False)
                ? value.GetBoolean()
                : fallback;

        return new GamePreferences
        {
            WarzoneFolder = Read("warzone_folder", Read("game_folder", "")),
            LegacyFolder = Read("legacy_folder", ""),
            LastPlayed = Read("last_played", "") == "legacy" ? "legacy" : "warzone",
            WarzoneMode = Read("launch_mode", "") == "steamvr" ? "steamvr" : "desktop",
            WindowLeft = ReadDouble("window_left"),
            WindowTop = ReadDouble("window_top"),
            WindowWidth = ReadDouble("window_width"),
            WindowHeight = ReadDouble("window_height"),
            WindowMaximized = ReadBool("window_maximized")
        };
    }

    internal string Serialize() => JsonSerializer.Serialize(new
    {
        warzone_folder = WarzoneFolder,
        legacy_folder = LegacyFolder,
        last_played = LastPlayed,
        launch_mode = WarzoneMode,
        window_left = WindowLeft,
        window_top = WindowTop,
        window_width = WindowWidth,
        window_height = WindowHeight,
        window_maximized = WindowMaximized
    });

    internal void Save(string path)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        string pending = path + "." + Guid.NewGuid().ToString("N") + ".pending";
        try
        {
            File.WriteAllText(pending, Serialize());
            Compatibility.MoveReplace(pending, path);
        }
        finally
        {
            if (File.Exists(pending)) File.Delete(pending);
        }
    }
}
