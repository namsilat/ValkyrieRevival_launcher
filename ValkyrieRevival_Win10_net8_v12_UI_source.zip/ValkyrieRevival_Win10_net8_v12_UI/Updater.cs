using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Signers;
using System.IO;
using System.Net.Http;

namespace ValkyrieRevival;

internal static class Updater
{
    private const int MaxExe = 157_286_400;

    internal static string Base => Program.Release.GetProperty("update_base_url").GetString()!.TrimEnd('/');
    internal static string Key => Program.Release.GetProperty("update_public_key").GetString()!;

    internal static Version ParseVersion(string value)
    {
        value = value.Trim().TrimStart('v');
        if (!Regex.IsMatch(value, @"\A(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\z"))
            throw new InvalidDataException("No release published yet.");
        return Version.Parse(value);
    }

    internal static ReleaseManifest Verify(byte[] manifestBytes, byte[] signatureBytes, string publicKeyHex)
    {
        var signer = new Ed25519Signer();
        signer.Init(false, new Ed25519PublicKeyParameters(Convert.FromHexString(publicKeyHex), 0));
        signer.BlockUpdate(manifestBytes, 0, manifestBytes.Length);
        byte[] signature = Convert.FromBase64String(Encoding.ASCII.GetString(signatureBytes).Trim());
        if (!signer.VerifySignature(signature))
            throw new InvalidDataException("Release signature verification failed.");

        using JsonDocument document = JsonDocument.Parse(manifestBytes);
        JsonElement root = document.RootElement;
        string[] keys = root.EnumerateObject().Select(x => x.Name).Order().ToArray();
        if (!keys.AsSpan().SequenceEqual(new[] { "file", "sha256", "size", "version" }))
            throw new InvalidDataException("Invalid release manifest.");

        var manifest = new ReleaseManifest(
            root.GetProperty("version").GetString()!,
            root.GetProperty("file").GetString()!,
            root.GetProperty("sha256").GetString()!,
            root.GetProperty("size").GetInt32());

        _ = ParseVersion(manifest.Version);
        if (!Regex.IsMatch(manifest.File, @"\AValkyrieRevival-[0-9]+\.[0-9]+\.[0-9]+\.exe\z") ||
            !Regex.IsMatch(manifest.Sha256, @"\A[a-f0-9]{64}\z") || manifest.Size <= 0 || manifest.Size > MaxExe)
            throw new InvalidDataException("Invalid release contents.");
        return manifest;
    }

    internal static async Task<byte[]> ReadBounded(Stream input, int limit, CancellationToken ct = default)
    {
        using var output = new MemoryStream();
        byte[] buffer = new byte[65_536];
        while (true)
        {
            int remaining = limit + 1 - checked((int)output.Length);
            int count = Math.Min(buffer.Length, remaining);
            int read = await input.ReadAsync(buffer.AsMemory(0, count), ct).ConfigureAwait(false);
            if (read == 0) break;
            output.Write(buffer, 0, read);
            if (output.Length > limit)
                throw new InvalidDataException("Response exceeds size limit.");
        }
        return output.ToArray();
    }

    internal static async Task<byte[]> Fetch(string url, int limit)
    {
        using var handler = new HttpClientHandler { AllowAutoRedirect = false, UseCookies = false };
        using var http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(90) };
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(90));

        for (int attempt = 0; attempt < 6; attempt++)
        {
            var uri = new Uri(url, UriKind.Absolute);
            if (uri.Scheme != Uri.UriSchemeHttps || !string.IsNullOrEmpty(uri.UserInfo))
                throw new IOException("HTTPS update URL required.");

            using var request = new HttpRequestMessage(HttpMethod.Get, uri);
            request.Headers.UserAgent.ParseAdd("ValkyrieRevivalLauncher/" + Program.Version);
            request.Headers.CacheControl = new CacheControlHeaderValue { NoCache = true };
            using HttpResponseMessage response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, timeout.Token).ConfigureAwait(false);

            if (response.StatusCode is HttpStatusCode.Moved or HttpStatusCode.Redirect or HttpStatusCode.RedirectMethod or HttpStatusCode.TemporaryRedirect or HttpStatusCode.PermanentRedirect)
            {
                Uri location = response.Headers.Location ?? throw new IOException("Invalid update redirect.");
                url = new Uri(uri, location).AbsoluteUri;
                continue;
            }

            response.EnsureSuccessStatusCode();
            await using Stream stream = await response.Content.ReadAsStreamAsync(timeout.Token).ConfigureAwait(false);
            return await ReadBounded(stream, limit, timeout.Token).ConfigureAwait(false);
        }
        throw new IOException("Too many update redirects.");
    }

    internal static async Task<bool> Check()
    {
        byte[] version = await Fetch(Base + "/version.txt", 128).ConfigureAwait(false);
        string remote = Encoding.UTF8.GetString(version).Trim();
        return ParseVersion(remote) > ParseVersion(Program.Version);
    }

    internal static async Task<string> Stage()
    {
        byte[] manifestBytes = await Fetch(Base + "/release.json", 8192).ConfigureAwait(false);
        byte[] signatureBytes = await Fetch(Base + "/release.sig", 256).ConfigureAwait(false);
        ReleaseManifest manifest = Verify(manifestBytes, signatureBytes, Key);
        if (ParseVersion(manifest.Version) <= ParseVersion(Program.Version))
            throw new IOException("No newer signed release is available.");

        byte[] executable = await Fetch(Base + "/" + manifest.File, manifest.Size).ConfigureAwait(false);
        if (executable.Length != manifest.Size || Program.Hash(executable) != manifest.Sha256)
            throw new IOException("Update checksum failed. Current launcher unchanged.");

        string directory = Path.Combine(Program.State, "update-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        File.WriteAllBytes(Path.Combine(directory, "package.exe"), executable);
        File.WriteAllBytes(Path.Combine(directory, "release.json"), manifestBytes);
        File.WriteAllBytes(Path.Combine(directory, "release.sig"), signatureBytes);
        return directory;
    }

    internal static void Start(string stageDirectory)
    {
        string executable = Compatibility.ExecutablePath();
        if (Path.GetFileName(executable) != "ValkyrieRevival.exe")
            throw new IOException("Keep the filename ValkyrieRevival.exe to use automatic updates.");

        File.WriteAllText(Path.Combine(stageDirectory, "request.json"), JsonSerializer.Serialize(new
        {
            pid = Environment.ProcessId,
            target = executable,
            old_sha256 = Program.FileHash(executable)
        }));

        string updater = Path.Combine(stageDirectory, "updater.exe");
        File.Copy(executable, updater, overwrite: false);
        var start = new ProcessStartInfo(updater)
        {
            UseShellExecute = false,
            CreateNoWindow = true,
            WorkingDirectory = stageDirectory
        };
        start.ArgumentList.Add("--apply-update");
        start.ArgumentList.Add(stageDirectory);
        Process.Start(start);
    }

    private static string Install(
        string directory,
        Action<int> wait,
        Action<string, string> verify,
        Action<string> start)
    {
        byte[] manifestBytes = File.ReadAllBytes(Path.Combine(directory, "release.json"));
        byte[] signatureBytes = File.ReadAllBytes(Path.Combine(directory, "release.sig"));
        ReleaseManifest manifest = Verify(manifestBytes, signatureBytes, Key);
        if (ParseVersion(manifest.Version) <= ParseVersion(Program.Version))
            throw new IOException("Refusing an old release.");

        using JsonDocument request = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(directory, "request.json")));
        int pid = request.RootElement.GetProperty("pid").GetInt32();
        string target = Path.GetFullPath(request.RootElement.GetProperty("target").GetString()!);
        string oldHash = request.RootElement.GetProperty("old_sha256").GetString()!;
        string package = Path.Combine(directory, "package.exe");

        if (!Path.GetFileName(target).Equals("ValkyrieRevival.exe", StringComparison.Ordinal) ||
            Path.GetFullPath(package).Equals(target, StringComparison.OrdinalIgnoreCase))
            throw new IOException("Invalid update destination.");
        if (new FileInfo(package).Length != manifest.Size || Program.FileHash(package) != manifest.Sha256)
            throw new IOException("Package changed after verification.");

        wait(pid);
        if (Program.FileHash(target) != oldHash)
            throw new IOException("Installed launcher changed. Update cancelled.");

        string previous = Path.Combine(Path.GetDirectoryName(target)!, "ValkyrieRevival.previous.exe");
        string pending = target + ".pending";
        File.Copy(target, previous, overwrite: true);
        try
        {
            File.Copy(package, pending, overwrite: true);
            if (Program.FileHash(pending) != manifest.Sha256)
                throw new IOException("Staged copy failed verification.");
            File.Move(pending, target, overwrite: true);
            verify(target, manifest.Version);
        }
        catch
        {
            if (File.Exists(previous)) File.Move(previous, target, overwrite: true);
            start(target);
            throw;
        }
        finally
        {
            if (File.Exists(pending)) File.Delete(pending);
        }

        start(target);
        return manifest.Version;
    }

    internal static void Apply(string directory)
    {
        try
        {
            string version = Install(
                directory,
                pid => Program.WaitProcess(pid, 60_000),
                (target, expected) =>
                {
                    string probe = Path.Combine(directory, "self-test.json");
                    if (File.Exists(probe)) File.Delete(probe);
                    var start = new ProcessStartInfo(target)
                    {
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        WorkingDirectory = Path.GetDirectoryName(target)!
                    };
                    start.ArgumentList.Add("--self-test");
                    start.ArgumentList.Add(probe);
                    using Process process = Process.Start(start) ?? throw new IOException("Updated launcher failed to start.");
                    if (!process.WaitForExit(45_000))
                    {
                        try { process.Kill(entireProcessTree: true); process.WaitForExit(); } catch { }
                        throw new IOException("Updated launcher startup timed out.");
                    }
                    if (process.ExitCode != 0 || !File.Exists(probe))
                        throw new IOException("Updated launcher failed its startup test.");
                    using JsonDocument result = JsonDocument.Parse(File.ReadAllBytes(probe));
                    if (result.RootElement.GetProperty("version").GetString() != expected ||
                        result.RootElement.GetProperty("assets").GetString() != "ok")
                        throw new IOException("Updated launcher version/assets mismatch.");
                },
                target => Process.Start(new ProcessStartInfo(target)
                {
                    UseShellExecute = false,
                    WorkingDirectory = Path.GetDirectoryName(target)!
                }));

            File.WriteAllText(Path.Combine(Program.State, "last-update.txt"), "Updated to " + version);
        }
        catch (Exception ex)
        {
            File.WriteAllText(Path.Combine(Program.State, "last-update.txt"), "Update failed: " + ex.Message);
        }
    }
}
