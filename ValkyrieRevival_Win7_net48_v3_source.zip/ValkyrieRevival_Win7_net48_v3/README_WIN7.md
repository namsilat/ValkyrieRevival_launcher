# Valkyrie Revival Legacy — Windows 7 SP1+

Separate compatibility branch based on the working Win10 v11 launcher.

## Target

- Windows 7 SP1 x64
- Windows 8.1 x64
- Windows 10 x64
- Windows 11 x64
- Microsoft .NET Framework 4.8

This branch keeps the current launcher UI, Login / Registration / Recover flows,
portable DPAPI credentials, recovery-code files, window placement persistence,
Warzone/Legacy patching, local bridge, Meta handling, and FriendsPatch compatibility.

## Important compatibility changes

- `.NET 8` target replaced with `.NET Framework 4.8`.
- TLS 1.2 is enabled explicitly at startup.
- Modern process APIs (`ArgumentList`, `WaitForExitAsync`, tree kill) replaced.
- Modern stream APIs (`ReadExactlyAsync`, Memory/Span overloads) replaced.
- `Convert.FromHexString` / `ToHexString` and `SHA256.HashData` replaced.
- `OpenFolderDialog` replaced with the .NET Framework WinForms folder browser.
- Newer File.Move overwrite APIs replaced with Win7-compatible helpers.
- `System.Text.Json` is supplied through NuGet's .NET Framework build.
- UI font falls back to `Segoe UI`, which is present on Windows 7.
- Official launcher self-update remains disabled so it cannot replace this branch with the .NET 10 official executable.

## Build

On the Windows 10 development PC, run:

    BUILD_WIN7.cmd

The script uses a private .NET 8 SDK only as the compiler. The produced launcher itself targets
.NET Framework 4.8 and does **not** need .NET 8 on the Windows 7 PC.

Output:

    publish\win7-x64\ValkyrieRevival-Legacy.exe
    publish\ValkyrieRevival-Legacy-Win7plus.zip

Do not copy only the EXE: keep the generated DLL files next to it.

## Target PC

Windows 7 must be SP1 and have .NET Framework 4.8 installed. The launcher is x64.
Steam, SteamVR, Meta/Oculus runtime, graphics drivers and the game itself have separate OS compatibility requirements.


## v3 compile fixes
- Replaced `Path.IsPathFullyQualified` with a net48-compatible helper.
- Replaced one-argument `FileStream.Write(byte[])`.
- Replaced LINQ `Order()` with `OrderBy(...)`.
- Cleaned nullable flow around bridge/session and recovery code.
