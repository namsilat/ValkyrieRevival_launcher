using System.Text;
using System.Text.Json;
using System.IO;
using System.Net.Http;

namespace ValkyrieRevival;

// Internal verification harness. Runtime launcher behavior does not depend on these tests.
internal static class Verification
{
    internal static async Task Connection(string report)
    {
        var remembered = Credentials.Load();
        if (remembered is null)
            throw new IOException("No remembered login available. Test using Play instead.");

        (int pilot, string session) = await Game.Authenticate(
            remembered.Value.User, remembered.Value.Password, registerWarzone: true).ConfigureAwait(false);

        using var bridge = new Bridge(pilot, session, 0);
        _ = bridge.Run();
        using var http = new HttpClient();
        using HttpResponseMessage response = await http.GetAsync(
            $"http://127.0.0.1:{bridge.Port}/live/pilots/{pilot}?properties=reputation").ConfigureAwait(false);
        response.EnsureSuccessStatusCode();
        using JsonDocument profile = JsonDocument.Parse(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
        Check(profile.RootElement.TryGetProperty("reputation", out _), "remote profile response");

        File.WriteAllText(report, JsonSerializer.Serialize(new
        {
            report,
            version = Program.Version,
            pilot,
            authentication = "ok",
            bridge = "ok",
            remote = "ok"
        }));
    }

    internal static void Check(bool condition, string label)
    {
        if (!condition) throw new InvalidDataException("Verification failed: " + label);
    }

    internal static void Reject(Action operation, string label)
    {
        try { operation(); }
        catch { return; }
        throw new InvalidDataException("Unsafe operation accepted: " + label);
    }

    private static byte[] Manifest(string version, string file) => JsonSerializer.SerializeToUtf8Bytes(new
    {
        version,
        file,
        sha256 = Program.Hash(new byte[] { 1, 2, 3 }),
        size = 3
    });

    internal static Task Run(string[] args)
    {
        string report = args.Length > 0 ? args[0] : Path.Combine(Program.State, "verification.json");
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(report))!);

        Check(Updater.ParseVersion("v1.2.3") == new Version(1, 2, 3), "semantic version parser");
        Reject(() => Updater.ParseVersion("01.2.3"), "non-canonical version");
        Reject(() => LegacyGame.CacheTenant(1), "invalid Legacy pilot");
        Check(LegacyGame.CacheTenant(2) == "revival-legacy-local-pilot-2", "Legacy tenant");
        Check(Game.Arguments("desktop").Contains("-2d"), "desktop arguments");
        Check(Game.Arguments("steamvr").Contains("-hmd=SteamVR"), "SteamVR arguments");

        using JsonDocument release = JsonDocument.Parse(Program.Resource("release.json"));
        Check(release.RootElement.GetProperty("game_api_url").GetString() == Program.Api, "release metadata");
        using JsonDocument patch = JsonDocument.Parse(Program.Resource("patch.json"));
        Check(patch.RootElement.TryGetProperty("target_sha256", out _), "patch recipe");

        File.WriteAllText(report, JsonSerializer.Serialize(new
        {
            version = Program.Version,
            assets = "ok",
            checks = "ok"
        }));
        return Task.CompletedTask;
    }
}
