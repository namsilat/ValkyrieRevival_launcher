@echo off
call "%~dp0BUILD_WIN7.cmd"
exit /b %ERRORLEVEL%
