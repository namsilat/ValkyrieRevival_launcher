using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;

namespace ValkyrieRevival;

internal static class Credentials
{
    // Portable credentials are stored next to the EXE, but the password payload
    // is protected with Windows DPAPI and is not written as plaintext.
    [StructLayout(LayoutKind.Sequential)]
    private struct DataBlob
    {
        public int Size;
        public IntPtr Data;
    }

    [DllImport("crypt32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool CryptProtectData(
        ref DataBlob dataIn,
        string? description,
        IntPtr optionalEntropy,
        IntPtr reserved,
        IntPtr prompt,
        uint flags,
        out DataBlob dataOut);

    [DllImport("crypt32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool CryptUnprotectData(
        ref DataBlob dataIn,
        IntPtr description,
        IntPtr optionalEntropy,
        IntPtr reserved,
        IntPtr prompt,
        uint flags,
        out DataBlob dataOut);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr LocalFree(IntPtr memory);

    // Old launcher credential-manager format, retained only for one-time migration.
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct WinCredential
    {
        public uint Flags;
        public uint Type;
        public string? TargetName;
        public string? Comment;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
        public uint CredentialBlobSize;
        public IntPtr CredentialBlob;
        public uint Persist;
        public uint AttributeCount;
        public IntPtr Attributes;
        public string? TargetAlias;
        public string? UserName;
    }

    [DllImport("advapi32", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool CredReadW(string target, uint type, uint flags, out IntPtr credential);

    [DllImport("advapi32", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool CredDeleteW(string target, uint type, uint flags);

    [DllImport("advapi32")]
    private static extern void CredFree(IntPtr buffer);

    private static string LegacyTarget => "ValkyrieRevival/Launcher/" +
        Program.Hash(Encoding.UTF8.GetBytes(Program.Account)).Substring(0, 24);

    internal static (string User, string Password)? Load()
    {
        if (File.Exists(Program.CredentialsFile))
            return LoadPortable();

        // Migrate an existing remembered login from Windows Credential Manager.
        var legacy = LoadLegacy();
        if (legacy is not null)
        {
            Save(legacy.Value.User, legacy.Value.Password);
            DeleteLegacy();
            return legacy;
        }

        return null;
    }

    private static (string User, string Password)? LoadPortable()
    {
        using JsonDocument document = JsonDocument.Parse(File.ReadAllText(Program.CredentialsFile));
        JsonElement root = document.RootElement;
        string user = root.GetProperty("user").GetString() ?? "";
        string protectedPassword = root.GetProperty("password_protected").GetString() ?? "";
        if (protectedPassword.Length == 0)
            return (user, "");

        byte[] encrypted = Convert.FromBase64String(protectedPassword);
        byte[] plain = Unprotect(encrypted);
        try
        {
            return (user, Encoding.UTF8.GetString(plain));
        }
        finally
        {
            Array.Clear(plain, 0, plain.Length);
        }
    }

    internal static void Save(string user, string password)
    {
        byte[] plain = Encoding.UTF8.GetBytes(password);
        byte[] encrypted;
        try
        {
            encrypted = Protect(plain);
        }
        finally
        {
            Array.Clear(plain, 0, plain.Length);
        }

        string json = JsonSerializer.Serialize(new
        {
            format = 1,
            protection = "windows-dpapi-current-user",
            user,
            password_protected = Convert.ToBase64String(encrypted)
        }, new JsonSerializerOptions { WriteIndented = true });

        string pending = Program.CredentialsFile + "." + Guid.NewGuid().ToString("N") + ".pending";
        try
        {
            File.WriteAllText(pending, json, Encoding.UTF8);
            Compatibility.MoveReplace(pending, Program.CredentialsFile);
        }
        finally
        {
            if (File.Exists(pending))
                File.Delete(pending);
        }
    }

    internal static void Forget()
    {
        if (File.Exists(Program.CredentialsFile))
            File.Delete(Program.CredentialsFile);
        DeleteLegacy();
    }

    private static byte[] Protect(byte[] input)
    {
        DataBlob inputBlob = BlobFrom(input);
        try
        {
            if (!CryptProtectData(ref inputBlob, "Valkyrie Revival launcher password", IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 0, out DataBlob outputBlob))
                throw new Win32Exception(Marshal.GetLastWin32Error());
            try
            {
                return BytesFrom(outputBlob);
            }
            finally
            {
                if (outputBlob.Data != IntPtr.Zero)
                    LocalFree(outputBlob.Data);
            }
        }
        finally
        {
            if (inputBlob.Data != IntPtr.Zero)
                Marshal.FreeHGlobal(inputBlob.Data);
        }
    }

    private static byte[] Unprotect(byte[] input)
    {
        DataBlob inputBlob = BlobFrom(input);
        try
        {
            if (!CryptUnprotectData(ref inputBlob, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 0, out DataBlob outputBlob))
                throw new Win32Exception(Marshal.GetLastWin32Error());
            try
            {
                return BytesFrom(outputBlob);
            }
            finally
            {
                if (outputBlob.Data != IntPtr.Zero)
                    LocalFree(outputBlob.Data);
            }
        }
        finally
        {
            if (inputBlob.Data != IntPtr.Zero)
                Marshal.FreeHGlobal(inputBlob.Data);
        }
    }

    private static DataBlob BlobFrom(byte[] bytes)
    {
        if (bytes.Length == 0)
            return default;

        IntPtr pointer = Marshal.AllocHGlobal(bytes.Length);
        Marshal.Copy(bytes, 0, pointer, bytes.Length);
        return new DataBlob { Size = bytes.Length, Data = pointer };
    }

    private static byte[] BytesFrom(DataBlob blob)
    {
        if (blob.Size <= 0 || blob.Data == IntPtr.Zero)
            return Array.Empty<byte>();

        byte[] result = new byte[blob.Size];
        Marshal.Copy(blob.Data, result, 0, blob.Size);
        return result;
    }

    private static (string User, string Password)? LoadLegacy()
    {
        if (!CredReadW(LegacyTarget, 1, 0, out IntPtr pointer))
        {
            int error = Marshal.GetLastWin32Error();
            if (error == 1168)
                return null;
            throw new Win32Exception(error);
        }

        try
        {
            WinCredential value = Marshal.PtrToStructure<WinCredential>(pointer);
            string password = Marshal.PtrToStringUni(value.CredentialBlob,
                checked((int)value.CredentialBlobSize) / 2) ?? "";
            return (value.UserName ?? "", password);
        }
        finally
        {
            CredFree(pointer);
        }
    }

    private static void DeleteLegacy()
    {
        if (CredDeleteW(LegacyTarget, 1, 0))
            return;
        int error = Marshal.GetLastWin32Error();
        if (error != 1168)
            throw new Win32Exception(error);
    }
}
