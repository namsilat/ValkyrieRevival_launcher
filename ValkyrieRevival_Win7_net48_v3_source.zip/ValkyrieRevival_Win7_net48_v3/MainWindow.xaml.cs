using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using Microsoft.Win32;

namespace ValkyrieRevival;

public partial class MainWindow : Window
{
    private bool busy;
    private bool loaded;
    private string mode = "desktop";
    private string selectedGame = "warzone";
    private GamePreferences preferences = new();
    private readonly bool services;

    private static readonly string Settings = Program.SettingsFile;
    private bool passwordVisible;
    private bool syncingPassword;
    private bool registrationPasswordVisible;
    private bool syncingRegistrationPassword;
    private bool recoverPasswordVisible;
    private bool syncingRecoverPassword;

    private static readonly Brush AccentBrush = BrushFrom("#D93647");
    private static readonly Brush AccentDarkBrush = BrushFrom("#5A151E");
    private static readonly Brush NeutralButtonBrush = BrushFrom("#141B23");
    private static readonly Brush NeutralBorderBrush = BrushFrom("#243140");
    private static readonly Brush PrimaryTextBrush = BrushFrom("#F4F6FA");
    private static readonly Brush SecondaryTextBrush = BrushFrom("#99A6B9");
    private static readonly Brush MutedTextBrush = BrushFrom("#677487");
    private static readonly Brush SuccessBrush = BrushFrom("#63D88E");
    private static readonly Brush ErrorBrush = BrushFrom("#FF8E8E");

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

    public MainWindow(bool services)
    {
        this.services = services;
        InitializeComponent();
        Title = "Valkyrie Revival — Community Launcher (Windows 7+)";
        VersionLabel.Text = "v" + Program.Version + " Legacy";
        ShowAccountTab("login");

        SourceInitialized += (_, _) =>
        {
            try
            {
                int dark = 1;
                DwmSetWindowAttribute(new WindowInteropHelper(this).Handle, 20, ref dark, sizeof(int));
            }
            catch
            {
            }
        };

        try
        {
            if (File.Exists(Settings))
                preferences = GamePreferences.Parse(File.ReadAllText(Settings));
        }
        catch
        {
            preferences = new GamePreferences();
        }

        RestoreWindowPlacement();

        try
        {
            var credentials = Credentials.Load();
            if (credentials is not null)
            {
                Username.Text = credentials.Value.User;
                Password.Password = credentials.Value.Password;
                Remember.IsChecked = true;
            }
        }
        catch
        {
            SetAccountStatus("Saved login unavailable. Please sign in again.", StatusTone.Error);
        }

        selectedGame = preferences.LastPlayed;
        GameChoice.SelectedIndex = selectedGame == "legacy" ? 1 : 0;
        ApplyGame();
        loaded = true;

        LocationChanged += (_, _) => CaptureWindowPlacement();
        SizeChanged += (_, _) => CaptureWindowPlacement();
        StateChanged += (_, _) => CaptureWindowPlacement();
        Closing += (_, _) => SaveWindowPlacement();

        if (services && Compatibility.OfficialLauncherUpdatesEnabled)
        {
            _ = CheckUpdates();
        }
        else
        {
            UpdateStatus.Text = "Windows 7+ compatibility build";
            UpdateStatus.Foreground = MutedTextBrush;
            UpdateButton.Visibility = Visibility.Collapsed;
        }
    }

    private static Brush BrushFrom(string color)
    {
        return new SolidColorBrush((Color)ColorConverter.ConvertFromString(color));
    }

    private void RestoreWindowPlacement()
    {
        if (preferences.WindowLeft is not double left ||
            preferences.WindowTop is not double top ||
            preferences.WindowWidth is not double savedWidth ||
            preferences.WindowHeight is not double savedHeight)
        {
            // First run (or no valid saved placement): start maximized.
            Loaded += (_, _) => WindowState = WindowState.Maximized;
            return;
        }

        double virtualLeft = SystemParameters.VirtualScreenLeft;
        double virtualTop = SystemParameters.VirtualScreenTop;
        double virtualWidth = SystemParameters.VirtualScreenWidth;
        double virtualHeight = SystemParameters.VirtualScreenHeight;

        double width = Math.Max(MinWidth, Math.Min(savedWidth, virtualWidth));
        double height = Math.Max(MinHeight, Math.Min(savedHeight, virtualHeight));

        var savedRect = new Rect(left, top, width, height);
        var virtualRect = new Rect(virtualLeft, virtualTop, virtualWidth, virtualHeight);
        Rect visible = Rect.Intersect(savedRect, virtualRect);

        // Ignore stale coordinates from a disconnected/rearranged monitor.
        if (visible.IsEmpty || visible.Width < 120 || visible.Height < 80)
            return;

        WindowStartupLocation = WindowStartupLocation.Manual;
        Width = width;
        Height = height;

        // Keep at least a useful part of the title area reachable.
        Left = Math.Max(virtualLeft - width + 180, Math.Min(left, virtualLeft + virtualWidth - 180));
        Top = Math.Max(virtualTop, Math.Min(top, virtualTop + virtualHeight - 80));

        if (preferences.WindowMaximized)
            Loaded += (_, _) => WindowState = WindowState.Maximized;
    }

    private void CaptureWindowPlacement()
    {
        if (!loaded)
            return;

        Rect bounds = WindowState == WindowState.Normal
            ? new Rect(Left, Top, ActualWidth, ActualHeight)
            : RestoreBounds;

        if (!bounds.IsEmpty &&
            Compatibility.IsFinite(bounds.Left) &&
            Compatibility.IsFinite(bounds.Top) &&
            Compatibility.IsFinite(bounds.Width) &&
            Compatibility.IsFinite(bounds.Height) &&
            bounds.Width >= MinWidth &&
            bounds.Height >= MinHeight)
        {
            preferences.WindowLeft = bounds.Left;
            preferences.WindowTop = bounds.Top;
            preferences.WindowWidth = bounds.Width;
            preferences.WindowHeight = bounds.Height;
        }

        if (WindowState == WindowState.Maximized)
            preferences.WindowMaximized = true;
        else if (WindowState == WindowState.Normal)
            preferences.WindowMaximized = false;
    }

    private void SaveWindowPlacement()
    {
        try
        {
            CaptureWindowPlacement();
            preferences.Save(Settings);
        }
        catch
        {
            // Never prevent launcher shutdown because window placement could not be saved.
        }
    }

    private enum StatusTone
    {
        Neutral,
        Success,
        Error,
        Busy
    }

    private void SetStatus(string text, StatusTone tone = StatusTone.Neutral)
    {
        Status.Text = text;
        switch (tone)
        {
            case StatusTone.Success:
                Status.Foreground = SuccessBrush;
                StatusDot.Fill = SuccessBrush;
                break;
            case StatusTone.Error:
                Status.Foreground = ErrorBrush;
                StatusDot.Fill = ErrorBrush;
                break;
            case StatusTone.Busy:
                Status.Foreground = PrimaryTextBrush;
                StatusDot.Fill = AccentBrush;
                break;
            default:
                Status.Foreground = SecondaryTextBrush;
                StatusDot.Fill = MutedTextBrush;
                break;
        }
    }

    private void SetAccountStatus(string text, StatusTone tone = StatusTone.Neutral)
    {
        AccountStatus.Text = text;
        AccountStatus.Foreground = tone switch
        {
            StatusTone.Success => SuccessBrush,
            StatusTone.Error => ErrorBrush,
            StatusTone.Busy => PrimaryTextBrush,
            _ => SecondaryTextBrush
        };
    }

    private void ShowAccountTab(string tab)
    {
        bool login = tab == "login";

        LoginPanel.Visibility = login ? Visibility.Visible : Visibility.Collapsed;
        RegistrationPanel.Visibility = tab == "registration" ? Visibility.Visible : Visibility.Collapsed;
        RecoverPanel.Visibility = tab == "recover" ? Visibility.Visible : Visibility.Collapsed;

        // Game launch controls are relevant only while signing in.
        GameCard.Visibility = login ? Visibility.Visible : Visibility.Collapsed;
        LocationCard.Visibility = login ? Visibility.Visible : Visibility.Collapsed;
        LaunchCard.Visibility = login ? Visibility.Visible : Visibility.Collapsed;

        StyleAccountTab(LoginTabButton, login);
        StyleAccountTab(RegistrationTabButton, tab == "registration");
        StyleAccountTab(RecoverTabButton, tab == "recover");
    }

    private static void StyleAccountTab(Button button, bool selected)
    {
        button.Background = selected ? AccentDarkBrush : NeutralButtonBrush;
        button.BorderBrush = selected ? AccentBrush : NeutralBorderBrush;
        button.Foreground = PrimaryTextBrush;
    }

    private void ShowLoginTab(object sender, RoutedEventArgs e) => ShowAccountTab("login");
    private void ShowRegistrationTab(object sender, RoutedEventArgs e) => ShowAccountTab("registration");
    private void ShowRecoverTab(object sender, RoutedEventArgs e) => ShowAccountTab("recover");

    private void TogglePasswordVisibility(object sender, RoutedEventArgs e)
    {
        syncingPassword = true;
        try
        {
            if (!passwordVisible)
            {
                PasswordVisible.Text = Password.Password;
                Password.Visibility = Visibility.Collapsed;
                PasswordVisible.Visibility = Visibility.Visible;
                passwordVisible = true;
                PasswordEye.ToolTip = "Hide password";
                PasswordVisible.Focus();
                PasswordVisible.CaretIndex = PasswordVisible.Text.Length;
            }
            else
            {
                Password.Password = PasswordVisible.Text;
                PasswordVisible.Visibility = Visibility.Collapsed;
                Password.Visibility = Visibility.Visible;
                passwordVisible = false;
                PasswordEye.ToolTip = "Show password";
                Password.Focus();
            }
        }
        finally
        {
            syncingPassword = false;
        }
    }

    private void PasswordVisibleChanged(object sender, TextChangedEventArgs e)
    {
        if (syncingPassword || !passwordVisible)
            return;

        syncingPassword = true;
        try
        {
            Password.Password = PasswordVisible.Text;
        }
        finally
        {
            syncingPassword = false;
        }
    }

    private string CurrentPassword()
    {
        return passwordVisible ? PasswordVisible.Text : Password.Password;
    }

    private void ClearPassword()
    {
        syncingPassword = true;
        try
        {
            Password.Clear();
            PasswordVisible.Clear();
        }
        finally
        {
            syncingPassword = false;
        }
    }

    private void SetLoginPassword(string value)
    {
        syncingPassword = true;
        try
        {
            Password.Password = value;
            PasswordVisible.Text = value;
        }
        finally
        {
            syncingPassword = false;
        }
    }

    private void ToggleRegistrationPasswordVisibility(object sender, RoutedEventArgs e)
    {
        syncingRegistrationPassword = true;
        try
        {
            if (!registrationPasswordVisible)
            {
                RegistrationPasswordVisible.Text = RegistrationPassword.Password;
                RegistrationPassword.Visibility = Visibility.Collapsed;
                RegistrationPasswordVisible.Visibility = Visibility.Visible;
                registrationPasswordVisible = true;
                RegistrationPasswordEye.ToolTip = "Hide password";
                RegistrationPasswordVisible.Focus();
                RegistrationPasswordVisible.CaretIndex = RegistrationPasswordVisible.Text.Length;
            }
            else
            {
                RegistrationPassword.Password = RegistrationPasswordVisible.Text;
                RegistrationPasswordVisible.Visibility = Visibility.Collapsed;
                RegistrationPassword.Visibility = Visibility.Visible;
                registrationPasswordVisible = false;
                RegistrationPasswordEye.ToolTip = "Show password";
                RegistrationPassword.Focus();
            }
        }
        finally
        {
            syncingRegistrationPassword = false;
        }
    }

    private void RegistrationPasswordVisibleChanged(object sender, TextChangedEventArgs e)
    {
        if (syncingRegistrationPassword || !registrationPasswordVisible)
            return;

        syncingRegistrationPassword = true;
        try
        {
            RegistrationPassword.Password = RegistrationPasswordVisible.Text;
        }
        finally
        {
            syncingRegistrationPassword = false;
        }
    }

    private string CurrentRegistrationPassword() =>
        registrationPasswordVisible ? RegistrationPasswordVisible.Text : RegistrationPassword.Password;

    private void ToggleRecoverPasswordVisibility(object sender, RoutedEventArgs e)
    {
        syncingRecoverPassword = true;
        try
        {
            if (!recoverPasswordVisible)
            {
                RecoverPasswordVisible.Text = RecoverPassword.Password;
                RecoverPassword.Visibility = Visibility.Collapsed;
                RecoverPasswordVisible.Visibility = Visibility.Visible;
                recoverPasswordVisible = true;
                RecoverPasswordEye.ToolTip = "Hide password";
                RecoverPasswordVisible.Focus();
                RecoverPasswordVisible.CaretIndex = RecoverPasswordVisible.Text.Length;
            }
            else
            {
                RecoverPassword.Password = RecoverPasswordVisible.Text;
                RecoverPasswordVisible.Visibility = Visibility.Collapsed;
                RecoverPassword.Visibility = Visibility.Visible;
                recoverPasswordVisible = false;
                RecoverPasswordEye.ToolTip = "Show password";
                RecoverPassword.Focus();
            }
        }
        finally
        {
            syncingRecoverPassword = false;
        }
    }

    private void RecoverPasswordVisibleChanged(object sender, TextChangedEventArgs e)
    {
        if (syncingRecoverPassword || !recoverPasswordVisible)
            return;

        syncingRecoverPassword = true;
        try
        {
            RecoverPassword.Password = RecoverPasswordVisible.Text;
        }
        finally
        {
            syncingRecoverPassword = false;
        }
    }

    private string CurrentRecoverPassword() =>
        recoverPasswordVisible ? RecoverPasswordVisible.Text : RecoverPassword.Password;

    private static bool ValidNewPassword(string password) => password.Length is >= 15 and <= 128;

    private async void CreateAccount(object sender, RoutedEventArgs e)
    {
        if (busy)
            return;

        string username = RegistrationUsername.Text.Trim();
        string callsign = RegistrationCallsign.Text.Trim();
        string password = CurrentRegistrationPassword();

        if (string.IsNullOrWhiteSpace(username))
        {
            SetAccountStatus("Enter a username.", StatusTone.Error);
            return;
        }
        if (string.IsNullOrWhiteSpace(callsign))
        {
            SetAccountStatus("Enter a public callsign.", StatusTone.Error);
            return;
        }
        if (!ValidNewPassword(password))
        {
            SetAccountStatus("Password must contain 15–128 characters.", StatusTone.Error);
            return;
        }

        Busy(true);
        SetAccountStatus("Creating pilot account...", StatusTone.Busy);
        try
        {
            AccountService.RegistrationResult result = await AccountService.Register(username, callsign, password);

            RecoverUsername.Text = result.Username;
            RecoverCode.Text = result.RecoveryCode;

            string savedPath;
            try
            {
                savedPath = RecoveryCodeStore.Save(result.Username, result.Callsign, result.RecoveryCode);
            }
            catch (Exception saveError)
            {
                ShowAccountTab("recover");
                SetAccountStatus("Account created, but the recovery code could not be saved to disk. It is filled into the RECOVER tab; copy it somewhere safe. " + saveError.Message, StatusTone.Error);
                return;
            }

            Username.Text = result.Username;
            SetLoginPassword(password);
            ShowAccountTab("login");
            SetAccountStatus($"Account created. Recovery code saved to {Path.GetFileName(savedPath)}.", StatusTone.Success);
        }
        catch (Exception ex)
        {
            SetAccountStatus(ex.Message, StatusTone.Error);
        }
        finally
        {
            Busy(false);
        }
    }

    private async void RecoverAccount(object sender, RoutedEventArgs e)
    {
        if (busy)
            return;

        string username = RecoverUsername.Text.Trim();
        string recoveryCode = RecoverCode.Text.Trim();
        string newPassword = CurrentRecoverPassword();

        if (string.IsNullOrWhiteSpace(username))
        {
            SetAccountStatus("Enter the account username.", StatusTone.Error);
            return;
        }
        if (string.IsNullOrWhiteSpace(recoveryCode))
        {
            SetAccountStatus("Enter the saved recovery code.", StatusTone.Error);
            return;
        }
        if (!ValidNewPassword(newPassword))
        {
            SetAccountStatus("New password must contain 15–128 characters.", StatusTone.Error);
            return;
        }

        Busy(true);
        SetAccountStatus("Resetting password...", StatusTone.Busy);
        try
        {
            AccountService.RecoveryResult result = await AccountService.Recover(username, recoveryCode, newPassword);

            string? recoveryMessage = null;
            if (!string.IsNullOrWhiteSpace(result.RecoveryCode))
            {
                string newRecoveryCode = result.RecoveryCode!;
                RecoverCode.Text = newRecoveryCode;
                try
                {
                    string savedPath = RecoveryCodeStore.Save(result.Username, result.Callsign, newRecoveryCode);
                    recoveryMessage = $" New recovery code saved to {Path.GetFileName(savedPath)}.";
                }
                catch (Exception saveError)
                {
                    ShowAccountTab("recover");
                    SetAccountStatus("Password reset succeeded, but the new recovery code could not be saved to disk. It is still visible in this RECOVER tab; copy it somewhere safe. " + saveError.Message, StatusTone.Error);
                    return;
                }
            }

            Username.Text = result.Username;
            SetLoginPassword(newPassword);
            if (Remember.IsChecked == true)
                Credentials.Save(result.Username, newPassword);

            ShowAccountTab("login");
            SetAccountStatus("Password reset successfully." + recoveryMessage, StatusTone.Success);
        }
        catch (Exception ex)
        {
            SetAccountStatus(ex.Message, StatusTone.Error);
        }
        finally
        {
            Busy(false);
        }
    }

    private async Task CheckUpdates()
    {
        try
        {
            bool available = await Updater.Check();
            UpdateStatus.Text = available ? "Update available" : "Up to date";
            UpdateStatus.Foreground = available ? PrimaryTextBrush : MutedTextBrush;
            UpdateButton.Visibility = available ? Visibility.Visible : Visibility.Collapsed;
        }
        catch
        {
            UpdateStatus.Text = "Update check unavailable";
            UpdateStatus.Foreground = MutedTextBrush;
        }
    }

    private void UpdateModeButtons()
    {
        bool desktopSelected = mode.EndsWith("desktop", StringComparison.Ordinal);

        Desktop.Background = desktopSelected ? AccentDarkBrush : NeutralButtonBrush;
        Desktop.BorderBrush = desktopSelected ? AccentBrush : NeutralBorderBrush;
        Desktop.Foreground = PrimaryTextBrush;

        VR.Background = desktopSelected ? NeutralButtonBrush : AccentDarkBrush;
        VR.BorderBrush = desktopSelected ? NeutralBorderBrush : AccentBrush;
        VR.Foreground = PrimaryTextBrush;
    }

    private void Choose(string selected)
    {
        mode = selected;
        if (selectedGame == "warzone")
            preferences.WarzoneMode = mode;

        UpdateModeButtons();
        SetStatus(
            mode.EndsWith("desktop", StringComparison.Ordinal)
                ? "Press Play to sign in and launch. Keep the store app for your installation running."
                : "Connect your headset. Meta installs use Meta VR; Steam installs use SteamVR.",
            StatusTone.Neutral);
        SavePreferences();
    }

    private void SelectDesktop(object sender, RoutedEventArgs e) => Choose("desktop");

    private void SelectVR(object sender, RoutedEventArgs e) => Choose("steamvr");

    private void Browse(object sender, RoutedEventArgs e)
    {
        using (var dialog = new System.Windows.Forms.FolderBrowserDialog())
        {
            dialog.Description = "Select " + (selectedGame == "legacy" ? "Legacy" : "Warzone") + " installation";
            dialog.ShowNewFolderButton = false;
            if (!string.IsNullOrWhiteSpace(Folder.Text) && Directory.Exists(Folder.Text))
                dialog.SelectedPath = Folder.Text;

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                Folder.Text = dialog.SelectedPath;
                SavePreferences();
            }
        }
    }

    private void SavePreferences()
    {
        if (!loaded)
            return;
        try
        {
            preferences.SetFolder(selectedGame, Folder.Text.Trim());
            if (selectedGame == "warzone")
                preferences.WarzoneMode = mode;
            preferences.Save(Settings);
        }
        catch
        {
            SetStatus("Your folder preference could not be saved.", StatusTone.Error);
        }
    }

    private void GameChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!loaded)
            return;
        SavePreferences();
        selectedGame = GameChoice.SelectedIndex == 1 ? "legacy" : "warzone";
        ApplyGame();
    }

    private void ApplyGame()
    {
        bool legacy = selectedGame == "legacy";
        FolderLabel.Text = legacy ? "LEGACY LOCATION" : "WARZONE LOCATION";
        Desktop.IsEnabled = !legacy;
        VR.Content = legacy ? "SteamVR" : "VR (Auto)";
        mode = legacy ? "steamvr" : preferences.WarzoneMode;
        Folder.Text = preferences.Folder(selectedGame);
        GameHint.Visibility = legacy ? Visibility.Visible : Visibility.Collapsed;

        SetStatus(
            string.IsNullOrWhiteSpace(Folder.Text)
                ? "Choose your game folder to continue."
                : legacy
                    ? "SteamVR required. Sign in to launch Legacy."
                    : "Press Play to sign in and launch. Keep your store app running.",
            StatusTone.Neutral);
        UpdateModeButtons();
    }

    private void Forget(object sender, RoutedEventArgs e)
    {
        if (Remember.IsChecked == true)
            return;
        try
        {
            Credentials.Forget();
            ClearPassword();
        }
        catch
        {
            SetStatus("Saved login could not be removed.", StatusTone.Error);
        }
    }

    private void Discord(object sender, RoutedEventArgs e)
    {
        try
        {
            string url = Program.Release.GetProperty("discord_url").GetString()!;
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }
        catch
        {
            SetStatus("Could not open your browser.", StatusTone.Error);
        }
    }

    private void Busy(bool value)
    {
        busy = value;
        Inputs.IsEnabled = !value;
        Play.IsEnabled = !value;
        UpdateButton.IsEnabled = !value;
        Play.Opacity = value ? 0.92 : 1.0;
    }

    private async void PlayGame(object sender, RoutedEventArgs e)
    {
        if (busy)
            return;

        string user = Username.Text.Trim();
        string secret = CurrentPassword();
        string selected = Folder.Text.Trim();
        string selectedMode = mode;
        bool remember = Remember.IsChecked == true;
        SavePreferences();

        if (string.IsNullOrWhiteSpace(selected))
        {
            SetStatus("Select your " + (selectedGame == "legacy" ? "Legacy" : "Warzone") + " installation folder first.", StatusTone.Error);
            return;
        }
        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrEmpty(secret))
        {
            SetStatus("Enter your pilot username and password.", StatusTone.Error);
            return;
        }

        try
        {
            _ = Installation.Validate(selected, selectedGame);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            SetStatus(ex.Message, StatusTone.Error);
            return;
        }

        Busy(true);
        SetStatus("Signing in and preparing launch...", StatusTone.Busy);
        try
        {
            using Process game = await Task.Run(async () => selectedGame == "legacy"
                ? await LegacyGame.Launch(user, secret, selected)
                : await Game.Launch(user, secret, selected, selectedMode));

            bool exited = await Task.Run(() => game.WaitForExit(8000));
            if (exited)
                throw new IOException("The game closed during startup.");

            SetStatus(selectedGame == "legacy" ? "Legacy is running." : "Warzone is running.", StatusTone.Success);

            try
            {
                if (remember)
                    Credentials.Save(user, secret);
                else
                    Credentials.Forget();
            }
            catch
            {
                SetStatus((selectedGame == "legacy" ? "Legacy is running." : "Warzone is running.") + " Login preference could not be saved.", StatusTone.Success);
            }

            try
            {
                preferences.Launched(selectedGame);
                preferences.Save(Settings);
            }
            catch
            {
                SetStatus((selectedGame == "legacy" ? "Legacy is running." : "Warzone is running.") + " Launcher preference could not be saved.", StatusTone.Success);
            }

            if (!remember)
                ClearPassword();
        }
        catch (UnauthorizedAccessException)
        {
            SetStatus("Windows blocked access to the game folder. Check folder permissions and try again.", StatusTone.Error);
        }
        catch (Exception ex)
        {
            SetStatus(ex.Message, StatusTone.Error);
        }
        finally
        {
            Busy(false);
        }
    }

    private async void UpdateLauncher(object sender, RoutedEventArgs e)
    {
        if (!Compatibility.OfficialLauncherUpdatesEnabled)
        {
            SetStatus("Official launcher updates are disabled in the Windows 7+ compatibility build.", StatusTone.Error);
            return;
        }
        if (busy)
            return;
        Busy(true);
        SetStatus("Downloading signed launcher update...", StatusTone.Busy);
        try
        {
            string stage = await Updater.Stage();
            SetStatus("Update verified. Restarting launcher...", StatusTone.Busy);
            Updater.Start(stage);
            Close();
        }
        catch (Exception ex)
        {
            SetStatus(ex.Message, StatusTone.Error);
        }
        finally
        {
            Busy(false);
        }
    }
}
