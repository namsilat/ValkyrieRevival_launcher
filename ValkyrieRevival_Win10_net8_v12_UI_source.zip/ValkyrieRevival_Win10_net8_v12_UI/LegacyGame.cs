using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace ValkyrieRevival;

internal static class LegacyGame
{
    private static JsonElement Recipe => JsonDocument.Parse(Program.Resource("legacy-patch.json")).RootElement;

    internal static byte[] Patch(byte[] input)
    {
        JsonElement recipe = Recipe;
        if (Program.Hash(input) != recipe.GetProperty("source_sha256").GetString())
            throw new IOException("Unsupported Legacy build.");

        byte[] append = Convert.FromHexString(recipe.GetProperty("append").GetString() ?? "");
        byte[] output = new byte[input.Length + append.Length];
        input.CopyTo(output, 0);
        append.CopyTo(output, input.Length);

        foreach (JsonElement change in recipe.GetProperty("changes").EnumerateArray())
        {
            int offset = change.GetProperty("offset").GetInt32();
            byte[] before = Convert.FromHexString(change.GetProperty("before").GetString()!);
            byte[] after = Convert.FromHexString(change.GetProperty("after").GetString()!);
            if (before.Length != after.Length || offset < 0 || offset + before.Length > output.Length ||
                !output.AsSpan(offset, before.Length).SequenceEqual(before))
                throw new IOException("Legacy patch verification failed.");
            after.CopyTo(output.AsSpan(offset, after.Length));
        }

        // The original performs an additional fixed-width UTF-16 port rewrite.
        byte[] from = Encoding.Unicode.GetBytes("18078");
        byte[] to = Encoding.Unicode.GetBytes("10080");
        for (int i = 0; i <= output.Length - from.Length; i++)
        {
            if (!output.AsSpan(i, from.Length).SequenceEqual(from)) continue;
            to.CopyTo(output.AsSpan(i, to.Length));
            i += from.Length - 1;
        }

        if (Program.Hash(output) != recipe.GetProperty("target_sha256").GetString())
            throw new IOException("Legacy patch checksum failed.");
        return output;
    }

    private static void Install(string path, byte[] data)
    {
        string hash = Program.Hash(data);
        if (File.Exists(path))
        {
            if (Program.FileHash(path) != hash)
                throw new IOException("Unexpected Legacy helper file: " + Path.GetFileName(path));
            return;
        }

        string pending = path + "." + Guid.NewGuid().ToString("N") + ".pending";
        try
        {
            File.WriteAllBytes(pending, data);
            File.Move(pending, path);
        }
        finally
        {
            if (File.Exists(pending)) File.Delete(pending);
        }
    }

    internal static string Prepare(string selected)
    {
        string input = Installation.Validate(selected, "legacy");
        string directory = Path.GetDirectoryName(input)!;
        byte[] patched = Patch(File.ReadAllBytes(input));
        byte[] guard = Program.Resource("legacy-guard.dll");
        JsonElement recipe = Recipe;

        if (Program.Hash(guard) != recipe.GetProperty("guard_sha256").GetString())
            throw new IOException("Legacy network helper checksum failed.");

        Install(Path.Combine(directory, "lgsep.dll"), guard);
        string client = Path.Combine(directory, "Valkyrie-Legacy-Bridge-" + Program.Hash(patched)[..12] + ".exe");
        Install(client, patched);
        return client;
    }

    internal static void VerifyPrepared(string executable)
    {
        JsonElement recipe = Recipe;
        if (!Path.GetFileName(executable).StartsWith("Valkyrie-Legacy-Bridge-", StringComparison.Ordinal) ||
            Program.FileHash(executable) != recipe.GetProperty("target_sha256").GetString())
            throw new IOException("Invalid Legacy bridge client.");

        string guard = Path.Combine(Path.GetDirectoryName(executable)!, "lgsep.dll");
        if (!File.Exists(guard) || Program.FileHash(guard) != recipe.GetProperty("guard_sha256").GetString())
            throw new IOException("Invalid Legacy network helper.");
    }

    internal static string CacheTenant(int pilot)
    {
        if (pilot < 2) throw new IOException("Invalid Legacy pilot identity.");
        return "revival-legacy-local-pilot-" + pilot;
    }

    internal static Process Start(string executable, int pilot)
    {
        VerifyPrepared(executable);
        var start = new ProcessStartInfo(executable)
        {
            UseShellExecute = false,
            WorkingDirectory = Path.GetDirectoryName(executable)!
        };

        string[] args =
        [
            "-steam", "-nosteam", "-vr", "-hmd=SteamVR",
            "-tenant=" + CacheTenant(pilot), "-localhost", "-NotInstalled", "-NotInstalledEngine",
            "-port=18777", "-QueryPort=18778",
            "-MULTIHOME=" + (LegacyEndpoint.Base == LegacyEndpoint.Live ? "0.0.0.0" : "127.0.0.1"),
            "-windowed", "-ResX=1280", "-ResY=720"
        ];
        foreach (string arg in args) start.ArgumentList.Add(arg);

        start.Environment["SteamAppId"] = "538870";
        start.Environment["SteamGameId"] = "538870";
        start.Environment["OPENSSL_ia32cap"] = ":~0x20000000";
        start.Environment.Remove("VALKYRIE_REMOTE_SESSION");

        Directory.CreateDirectory(Program.State);
        File.WriteAllText(Path.Combine(Program.State, "legacy-native-launch.json"), JsonSerializer.Serialize(new
        {
            time = DateTimeOffset.UtcNow,
            executable,
            pilot,
            endpoint = LegacyEndpoint.Base
        }));

        Process process = Process.Start(start) ?? throw new IOException("Cannot start Legacy.");
        process.EnableRaisingEvents = true;
        process.Exited += (_, _) =>
        {
            try
            {
                File.WriteAllText(Path.Combine(Program.State, "legacy-exit.json"), JsonSerializer.Serialize(new
                {
                    time = DateTimeOffset.UtcNow,
                    pid = process.Id,
                    exit_code = process.ExitCode
                }));
            }
            catch { }
        };
        return process;
    }

    internal static async Task<Process> Launch(string user, string password, string selected)
    {
        _ = Installation.Validate(selected, "legacy");
        if (Game.Running())
            throw new IOException("Close the running game before launching Legacy.");

        Process[] steamProcesses = Process.GetProcessesByName("steam");
        bool steamRunning = steamProcesses.Length > 0;
        foreach (Process steam in steamProcesses) steam.Dispose();
        if (!steamRunning)
            throw new IOException("Start Steam before launching Legacy.");

        using var handler = new HttpClientHandler { AllowAutoRedirect = false, UseCookies = false };
        using var http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(20) };
        try
        {
            using HttpResponseMessage health = await http.GetAsync(LegacyEndpoint.Base + "/health").ConfigureAwait(false);
            health.EnsureSuccessStatusCode();
            using JsonDocument doc = JsonDocument.Parse(await health.Content.ReadAsStringAsync().ConfigureAwait(false));
            if (doc.RootElement.GetProperty("game").GetString() != "legacy")
                throw new IOException("Unexpected service on Legacy's port.");
        }
        catch
        {
            throw new IOException("The selected Legacy test server is unavailable.");
        }

        (int pilot, string session) = await Game.Authenticate(user, password, registerWarzone: false).ConfigureAwait(false);
        using (var registration = new HttpRequestMessage(HttpMethod.Post, LegacyEndpoint.Base + "/live/clients")
        {
            Content = new StringContent("{}", Encoding.UTF8, "application/json")
        })
        {
            registration.Headers.Authorization = new AuthenticationHeaderValue("Bearer", session);
            using HttpResponseMessage assigned = await http.SendAsync(registration).ConfigureAwait(false);
            assigned.EnsureSuccessStatusCode();
            using JsonDocument doc = JsonDocument.Parse(await assigned.Content.ReadAsStringAsync().ConfigureAwait(false));
            if (doc.RootElement.GetProperty("pilot_id").GetInt32() != pilot)
                throw new IOException("Legacy account assignment mismatch.");
        }

        string client = Prepare(selected);
        var start = Program.Self("--game-host");
        start.RedirectStandardInput = true;
        start.RedirectStandardOutput = true;
        start.RedirectStandardError = true;
        Process bridge = Process.Start(start) ?? throw new IOException("Cannot start Legacy bridge.");
        try
        {
            await bridge.StandardInput.WriteLineAsync(JsonSerializer.Serialize(new { pilot, session, game = "legacy" })).ConfigureAwait(false);
            await bridge.StandardInput.FlushAsync().ConfigureAwait(false);
            string? ready = await bridge.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(15)).ConfigureAwait(false);
            if (ready != "READY")
            {
                string stderr = await bridge.StandardError.ReadToEndAsync().ConfigureAwait(false);
                File.WriteAllText(Path.Combine(Program.State, "legacy-bridge-startup-error.txt"), "READY=" + ready + "\n" + stderr);
                throw new IOException("Legacy bridge failed to start: " + (stderr.Trim().Length > 0 ? stderr.Trim() : ready));
            }

            await bridge.StandardInput.WriteLineAsync(JsonSerializer.Serialize(new { executable = client, mode = "steamvr" })).ConfigureAwait(false);
            await bridge.StandardInput.FlushAsync().ConfigureAwait(false);
            string? line = await bridge.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(15)).ConfigureAwait(false);
            if (line is null || !line.StartsWith("PID:", StringComparison.Ordinal) || !int.TryParse(line[4..], out int pid))
                throw new IOException("Legacy startup failed.");

            bridge.StandardInput.Close();
            return Process.GetProcessById(pid);
        }
        catch
        {
            try { if (!bridge.HasExited) bridge.Kill(entireProcessTree: true); } catch { }
            throw;
        }
        finally
        {
            bridge.Dispose();
        }
    }
}
