namespace ValkyrieRevival;

internal sealed class ReleaseManifest
{
    internal ReleaseManifest(string version, string file, string sha256, int size)
    { Version = version; File = file; Sha256 = sha256; Size = size; }
    internal string Version { get; }
    internal string File { get; }
    internal string Sha256 { get; }
    internal int Size { get; }
}
