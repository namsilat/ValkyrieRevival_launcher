using System.Diagnostics;
using System.Runtime.InteropServices;
using System.IO;

namespace ValkyrieRevival;

internal static class Compatibility
{
    internal const string BuildFlavor = "Win10 compatibility / .NET 8 self-contained";
    internal static readonly bool OfficialLauncherUpdatesEnabled = false;

    internal static string HexLower(byte[] data) =>
        Convert.ToHexString(data).ToLowerInvariant();

    internal static string HexLower(ReadOnlySpan<byte> data) =>
        Convert.ToHexString(data).ToLowerInvariant();

    internal static string ExecutablePath()
    {
        if (!string.IsNullOrWhiteSpace(Environment.ProcessPath))
            return Environment.ProcessPath;

        try
        {
            string? native = Process.GetCurrentProcess().MainModule?.FileName;
            if (!string.IsNullOrWhiteSpace(native))
                return native;
        }
        catch
        {
        }

        string[] args = Environment.GetCommandLineArgs();
        if (args.Length > 0 && !string.IsNullOrWhiteSpace(args[0]))
        {
            string commandPath = Path.GetFullPath(args[0]);
            if (File.Exists(commandPath))
                return commandPath;
        }

        throw new IOException("Cannot locate launcher executable.");
    }

    internal static void LogStartup(string message)
    {
        try
        {
            Directory.CreateDirectory(Program.State);
            File.AppendAllText(
                Path.Combine(Program.State, "startup.log"),
                $"[{DateTimeOffset.Now:O}] {message}{Environment.NewLine}");
        }
        catch
        {
        }
    }

    internal static string EnvironmentDescription() =>
        $"{BuildFlavor}; OS={RuntimeInformation.OSDescription}; " +
        $"Framework={RuntimeInformation.FrameworkDescription}; " +
        $"Arch={RuntimeInformation.ProcessArchitecture}; " +
        $"64bit={Environment.Is64BitProcess}";
}
