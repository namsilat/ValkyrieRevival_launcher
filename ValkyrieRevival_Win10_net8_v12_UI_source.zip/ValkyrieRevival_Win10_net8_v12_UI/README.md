# ValkyrieRevival 0.2.8 — readable reconstruction

This directory is a source-level reconstruction of `ValkyrieRevival.exe` / `ValkyrieRevival.dll`.
It is **not claimed to be the author's original source tree**. It was recovered from CLR metadata,
IL, embedded resources and WPF BAML from the supplied binary.

## Recovery status

High-confidence runtime reconstruction:

- `Game.cs` — Warzone discovery, patching, remote authentication patch, authentication, launch, Steam checks.
- `Bridge.cs` — loopback HTTP bridge, request validation, forwarding, URL rewriting and game-host mode.
- `LegacyGame.cs` — Legacy patch/install/start/authentication/bridge flow.
- `Updater.cs` — signed update manifest validation, HTTPS fetch, staging and rollback update path.
- `MetaLaunchLease.cs` — Meta executable swap, SHA-256 backup, lock and recovery.
- `MetaRuntime.cs` — Oculus/Meta runtime discovery.
- `Installation.cs`, `DesktopAudio.cs`, `Credentials.cs`, preferences and endpoint helpers.

Reconstructed with lower byte-for-byte confidence:

- `MainWindow.xaml` layout: reconstructed from the original `mainwindow.baml`; behavior in
  `MainWindow.xaml.cs` follows the compiled methods, but visual markup is not byte-identical XAML.
- `Verification.cs`: the production-independent verification harness is reconstructed semantically;
  the original binary contains more private test modes. Full original IL is included.
- `Program.cs`: production dispatch is restored. Several developer-only command-line verification
  modes present in 0.2.8 are intentionally represented by the preserved IL rather than duplicated.

## Build

Requires Windows and .NET 10 SDK:

```powershell
dotnet restore
dotnet build -c Release
```

The only NuGet dependency observed in the original `.deps.json` is:

- `BouncyCastle.Cryptography` 2.7.0

## Original evidence

- `OriginalBinary/ValkyrieRevival.dll` — extracted managed assembly.
- `OriginalBinary/mainwindow.baml` — original compiled WPF markup.
- `OriginalIL/ValkyrieRevival.il.txt` — full IL dump of all methods.
- `OriginalIL/api.txt` — recovered CLR type/method inventory.
- `Embedded/` — original patch recipes, release metadata and Legacy network helper.

## Important hashes recovered from the binary

- Meta original: `68220d1c8b70cf94ed6c37b245cf3f756ec1a46d646d39f914e4aaa8e1de37b6`
- Meta handoff: `357e51eed499e73c7ad7b3a090733829a516436f57b414b10e255661fe79e0fd`
- Legacy original: `b0e1eef5aa308b8bdd58855918cbf6f49382aafc0e761ce2c7e15f0efeb3aca3`

## Verification limitation in this environment

The reconstruction was statically checked against the extracted IL and embedded recipes. The
current analysis container has no `dotnet`, `csc`, `msbuild` or Mono installation, so a real Windows
WPF compilation could not be executed here. Build errors, if any, should be small source/XAML API
mismatches rather than missing application logic; the original IL remains alongside the source for
comparison.


## Compatibility source revision

This package is **v3**. `BUILD_COMPAT_VERSION.txt` must say `Win10 compatibility source v3`.

## v9 additions

- Native PILOT LOGIN / REGISTRATION / RECOVER tabs.
- Official `/api/register` and `/api/recover` account flows.
- Registration recovery code saved beside the EXE as `recovery-code-<username>.txt`.
- A replacement recovery code returned by password reset is saved automatically.
